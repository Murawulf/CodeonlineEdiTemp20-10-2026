import { Card, CardContent, CardHeader, CardDescription } from "@/components/ui/card";
import {
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Sector, Legend, Tooltip
} from "recharts";
import { useState, useCallback, useEffect, useRef } from "react";
import { brickData } from "../pages/bricks";
import { nmcData } from "../pages/nmcCodes";
import { initialSelections } from "../pages/initialSelections";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";

// API Base URL
const API_BASE_URL = "https://edi-dev.codeonline-info.com";

// Color Palette
const ACCENT = "#1E3A8A"; // Deep Blue
const SECONDARY = "#10B981"; // Vibrant Green
const COLORS = [ACCENT, SECONDARY, "#F59E0B", "#EF4444", "#8B5CF6", "#F472B6", "#3B82F6", "#F97316", "#22D3EE", "#6EE7B7"];

// Interfaces
interface AuthUser {
  name: string;
  prenom: string | null;
  initials: string;
  avatar_url?: string | null;
  profile_id: number | null;
  id_compte?: number;
}

interface Compte {
  id_compte: number;
  id_entite: number;
}

interface Producteur {
  id_entite: number;
  logo: string;
}

// Web Worker Script (fixed to post per batch)
const workerScript = `
  const normalizeText = (text) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\\u0300-\\u036f]/g, '')
      .replace(/[^a-z0-9\\s]/g, '');
  };
  const levenshteinDistance = (a, b) => {
    const matrix = Array(b.length + 1).fill().map(() => Array(a.length + 1).fill(0));
    for (let i = 0; i <= a.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= b.length; j++) matrix[j][0] = j;
    for (let j = 1; j <= b.length; j++) {
      for (let i = 1; i <= a.length; i++) {
        const indicator = a[i - 1] === b[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + indicator
        );
      }
    }
    return matrix[b.length][a.length];
  };
  const calculateSimilarity = (brickLabel, nmc, brickCategoryHints, productHints) => {
    const normBrick = normalizeText(brickLabel);
    const normNmc = normalizeText(nmc.LibelleNmc);
    const words1 = normBrick.split(/\\s+/).filter(Boolean);
    const words2 = normNmc.split(/\\s+/).filter(Boolean);
    const commonWords = words1.filter(word => words2.includes(word));
    let similarity = commonWords.length / Math.max(words1.length, words2.length, 1);
    const levDistance = levenshteinDistance(normBrick, normNmc);
    const maxLength = Math.max(normBrick.length, normNmc.length);
    similarity += (1 - levDistance / maxLength) * 0.3;
    const brickCategories = brickCategoryHints || [];
    const nmcCategory = normalizeText(nmc.category);
    if (brickCategories.some(cat => nmcCategory === cat)) {
      similarity += 0.5;
    } else if (brickCategories.some(cat => nmcCategory.includes(cat.split(' ')[0]))) {
      similarity += 0.25;
    }
    const codeLength = String(nmc.CodeNmc).length;
    if (codeLength > 5) {
      similarity += 0.3;
    } else if (codeLength > 3) {
      similarity += 0.15;
    }
    const keyTerms = ['bio', 'exotique', 'frais', 'emballe', 'legumes', 'fruits', 'poisson', 'cremerie', 'fromage', 'lait', 'pain', 'croissant', 'viande', 'parfum', 'savon', 'eau', 'soda', 'bijoux'];
    const hasKeyTerm = keyTerms.some(term => normBrick.includes(term) && normNmc.includes(term));
    if (hasKeyTerm) {
      similarity += 0.25;
    }
    const productMatch = productHints.some(hint => nmc.CodeNmc === hint || normNmc.includes(normalizeText(hint)));
    if (productMatch) {
      similarity += 0.6;
    }
    return Math.min(similarity, 2.0);
  };
  self.onmessage = function(e) {
    const { brickData, nmcData, startIndex, endIndex, pause, totalBricks, keywordToCategory, productToNmc, nmcByCategory, nmcByKeyTerm, initialSelections, existingSelections } = e.data;
    if (pause) return;
    try {
      const selections = {};
      const errors = [];
      for (let i = startIndex; i < endIndex && i < brickData.length; i++) {
        const brick = brickData[i];
        if (!brick || !brick.code || !brick.label) {
          errors.push(\`Invalid brick at index \${i}: \${JSON.stringify(brick)}\`);
          continue;
        }
        const normalizedBrickCode = String(brick.code).trim().toLowerCase();
        if (initialSelections[normalizedBrickCode]?.length > 0 || existingSelections[normalizedBrickCode]?.length > 0) {
          selections[normalizedBrickCode] = existingSelections[normalizedBrickCode] || initialSelections[normalizedBrickCode];
          continue;
        }
        const brickWords = normalizeText(brick.label).split(/\\s+/).filter(Boolean);
        const brickCategoryHints = brickWords
          .filter(word => Object.keys(keywordToCategory).includes(word))
          .map(word => normalizeText(keywordToCategory[word]));
        const productHints = brickWords.flatMap(word => productToNmc[word] || []);
        let relevantNmcs = [];
        if (brickCategoryHints.length > 0) {
          brickCategoryHints.forEach(cat => {
            relevantNmcs.push(...(nmcByCategory[cat] || []));
          });
        }
        brickWords.forEach(word => {
          if (nmcByKeyTerm[word]) {
            relevantNmcs.push(...nmcByKeyTerm[word]);
          }
        });
        relevantNmcs = [...new Set(relevantNmcs)];
        if (relevantNmcs.length === 0) {
          relevantNmcs = nmcData;
        }
        const matchedNMCs = relevantNmcs
          .map(nmc => ({
            ...nmc,
            similarity: calculateSimilarity(brick.label, nmc, brickCategoryHints, productHints)
          }))
          .filter(item => item.similarity > 0.3)
          .sort((a, b) => {
            const aCatMatch = brickCategoryHints.some(cat => normalizeText(a.category) === cat) ? 1 : 0;
            const bCatMatch = brickCategoryHints.some(cat => normalizeText(b.category) === cat) ? 1 : 0;
            if (aCatMatch !== bCatMatch) return bCatMatch - aCatMatch;
            if (b.similarity !== a.similarity) return b.similarity - a.similarity;
            return String(b.CodeNmc).length - String(a.CodeNmc).length;
          })
          .slice(0, 3)
          .map(nmc => ({
            CodeNmc: nmc.CodeNmc,
            LibelleNmc: nmc.LibelleNmc
          }));
        selections[normalizedBrickCode] = matchedNMCs;
      }
      const processed = Math.min(endIndex, brickData.length);
      self.postMessage({
        progress: processed / totalBricks,
        selections,
        index: processed - 1,
        errors
      });
      if (processed >= brickData.length) {
        self.postMessage({ done: true, selections: {}, index: brickData.length - 1, errors: [] });
      }
    } catch (error) {
      self.postMessage({ error: error.message, index: startIndex, errors: [\`Fatal error: \${error.message}\`] });
    }
  };
`;

// Data
const enterpriseData = [
  { name: "Nourriture/Soins pour animal", value: 1, color: COLORS[0] },
  { name: "Ingénierie & Services", value: 5, color: COLORS[1] },
  { name: "Produits Entretien/Nettoyage", value: 1, color: COLORS[2] },
  { name: "Nourriture/Boisson", value: 3, color: COLORS[3] },
  { name: "Santé", value: 1, color: COLORS[4] },
  { name: "Beauté/Soin Personnel/Hygiène", value: 1, color: COLORS[5] },
  { name: "Chaussures", value: 3, color: COLORS[0] },
  { name: "Accessoires Corporels", value: 2, color: COLORS[1] },
  { name: "Vêtements Habillement Textile", value: 4, color: COLORS[2] },
  { name: "Equipements Sportifs", value: 1, color: COLORS[3] },
  { name: "Métiers d'Art - Série Limitée", value: 2, color: COLORS[4] }
];

const productSheetData = [
  { name: "Nourriture/Boisson", value: 11, color: COLORS[0] },
  { name: "Beauté/Soin Personnel/Hygiène", value: 21, color: COLORS[1] },
  { name: "Chaussures", value: 42, color: COLORS[2] },
  { name: "Vêtements Habillement Textile", value: 99, color: COLORS[3] },
  { name: "Métiers d'Art - Série Limitée", value: 16, color: COLORS[4] }
];

const totalBricks = brickData.length;
const totalNmcCodes = 14266;

// Progress Pie Component
const ProgressPie = ({ value, maxValue, label }: { value: number; maxValue: number; label: string }) => {
  const percentage = Math.min(Math.round((value / maxValue) * 100), 100);
  const data = [
    { name: 'Progress', value, fill: ACCENT },
    { name: 'Remaining', value: maxValue - value, fill: '#E0F2FE' }
  ];

  return (
    <div className="relative w-full h-48 mx-auto">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            dataKey="value"
            startAngle={90}
            endAngle={-270}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.fill} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.p
          className="text-3xl font-bold"
          style={{ color: ACCENT }}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          {percentage}%
        </motion.p>
        <motion.p
          className="text-sm font-medium"
          style={{ color: ACCENT }}
          initial={{ y: 5, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          {label}
        </motion.p>
      </div>
    </div>
  );
};

const Index: React.FC = () => {
  const [activeRayonIndex, setActiveRayonIndex] = useState(-1);
  const [activeEnterpriseIndex, setActiveEnterpriseIndex] = useState(-1);
  const [brickNmcSelections, setBrickNmcSelections] = useState(initialSelections);
  const [mappingProgress, setMappingProgress] = useState(0);
  const [mappedCount, setMappedCount] = useState(0);
  const [entitiesCount, setEntitiesCount] = useState(0);
  const [rayonData, setRayonData] = useState([
    { name: "Mappé", value: 0, color: ACCENT },
    { name: "Non Mappé", value: totalNmcCodes, color: "#F97316" },
  ]);
  const [brickMappingData, setBrickMappingData] = useState([
    { name: "0 Rayons", value: totalBricks, color: "#F97316" },
    { name: "1 Rayon", value: 0, color: ACCENT },
    { name: "2 Rayons", value: 0, color: SECONDARY },
    { name: "3+ Rayons", value: 0, color: "#8B5CF6" },
  ]);

  // Auth and Company Logo States
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [logoLoadError, setLogoLoadError] = useState(false);

  const workerRef = useRef<Worker | null>(null);
  const currentSelectionsRef = useRef(initialSelections);
  const batchSizeRef = useRef(10);
  const performanceStartRef = useRef<number | null>(null);
  const errorLogRef = useRef<string[]>([]);

  // Web Worker Dependencies
  const keywordToCategory = {};
  const productToNmc = {};
  const nmcByCategory = {};
  const nmcByKeyTerm = {};

  // Placeholder Logo
  const placeholderLogo = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjgiIHZpZXdCb3g9IjAgMCAyOCAyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjI4IiBoZWlnaHQ9IjI4IiByeD0iMTQiIGZpbGw9IiNDQ0NDQ0MiLz4KPHRleHQgeD0iMTQiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM2NjY2NjYiPkM8L3RleHQ+Cjwvc3ZnPgo=';
  const effectiveLogoSrc = companyLogo && !logoLoadError ? companyLogo : placeholderLogo;

  // Load User from LocalStorage
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        const userData = {
          name: parsedUser.name || "Utilisateur",
          prenom: parsedUser.prenom || null,
          initials: parsedUser.name ? parsedUser.name.slice(0, 2).toUpperCase() : "UA",
          avatar_url: parsedUser.avatar_url || null,
          profile_id: parsedUser.profile_id || null,
          id_compte: parsedUser.id_compte || null,
        };
        setUser(userData);
        setIsAuthenticated(true);
      } catch (err) {
        console.error("Failed to parse stored user:", err);
        localStorage.removeItem("user");
      }
    }
    setIsLoadingUser(false);
  }, []);

  // Fetch Company Logo
  useEffect(() => {
    const fetchCompanyLogo = async () => {
      if (isAuthenticated && user?.id_compte) {
        try {
          const comptesResponse = await fetch(`${API_BASE_URL}/api/comptes`, {
            headers: { Accept: "application/json" },
            credentials: "include",
          });
          if (!comptesResponse.ok) {
            console.log(`Failed to fetch comptes. Status: ${comptesResponse.status}`);
            return;
          }
          const comptes: Compte[] = await comptesResponse.json();
          const matchingCompte = comptes.find(c => c.id_compte === user.id_compte);
          if (!matchingCompte) {
            console.log(`No compte found for id: ${user.id_compte}`);
            return;
          }
          const id_entite = matchingCompte.id_entite;
          if (!id_entite) {
            console.log("No producteur associated with account");
            return;
          }

          const producteursResponse = await fetch(`${API_BASE_URL}/api/companies`, {
            headers: { Accept: "application/json" },
            credentials: "include",
          });
          if (!producteursResponse.ok) {
            console.log(`Failed to fetch companies. Status: ${producteursResponse.status}`);
            return;
          }
          const producteurs: Producteur[] = await producteursResponse.json();
          const matchingProducteur = producteurs.find(p => p.id_entite === id_entite);
          if (!matchingProducteur) {
            console.log(`No producteur found for id: ${id_entite}`);
            return;
          }
          setCompanyLogo(matchingProducteur.logo || null);
          setLogoLoadError(false);
        } catch (err: any) {
          console.error("Unexpected error fetching company logo:", err.message);
          setLogoLoadError(true);
        }
      }
    };
    fetchCompanyLogo();
  }, [isAuthenticated, user?.id_compte]);

  // Fetch Entities Count
  useEffect(() => {
    const fetchEntitiesCount = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/companies`, { withCredentials: true });
        setEntitiesCount(response.data.length);
      } catch (error) {
        console.error("Error fetching entities:", error);
        setEntitiesCount(0);
      }
    };
    fetchEntitiesCount();
  }, []);

  // Progress Update Handler (updated to take selections)
  const handleProgressUpdate = useCallback((mapped: number, total: number, selections: Record<string, any[]>) => {
    setMappedCount(mapped);
    setMappingProgress(Math.round((mapped / total) * 100));
    const mappingCounts: Record<number, number> = { 0: total - mapped, 1: 0, 2: 0, 3: 0 };
    Object.values(selections).forEach((sels: any[]) => {
      const count = sels.length;
      if (count >= 3) mappingCounts[3]++;
      else if (count > 0) mappingCounts[count]++;
    });
    setBrickMappingData([
      { name: "0 Rayons", value: mappingCounts[0], color: "#F97316" },
      { name: "1 Rayon", value: mappingCounts[1], color: ACCENT },
      { name: "2 Rayons", value: mappingCounts[2], color: SECONDARY },
      { name: "3+ Rayons", value: mappingCounts[3], color: "#8B5CF6" },
    ]);
  }, []);

  // NMC Update Handler
  const handleNmcUpdate = useCallback((mappedNmc: number, totalNmc: number) => {
    setRayonData([
      { name: "Mappé", value: mappedNmc, color: ACCENT },
      { name: "Non Mappé", value: totalNmc - mappedNmc, color: "#F97316" },
    ]);
  }, []);

  // Web Worker Initialization (fixed dependencies and batch posting)
  useEffect(() => {
    currentSelectionsRef.current = initialSelections;
    const blob = new Blob([workerScript], { type: "application/javascript" });
    const workerUrl = URL.createObjectURL(blob);
    workerRef.current = new Worker(workerUrl);
    workerRef.current.onmessage = (e) => {
      if (e.data.error) {
        errorLogRef.current = [...errorLogRef.current, e.data.error, ...e.data.errors];
        console.error("Worker error:", e.data.error);
      } else if (e.data.done) {
        console.log("Initial mapping completed");
        workerRef.current?.terminate();
      } else {
        const newSelections = e.data.selections;
        setBrickNmcSelections((prev) => {
          const updated = { ...prev, ...newSelections };
          currentSelectionsRef.current = updated;
          return updated;
        });
        const mapped = Object.keys(currentSelectionsRef.current).length;
        handleProgressUpdate(mapped, totalBricks, currentSelectionsRef.current);
        const totalMappedNmcs = Object.values(currentSelectionsRef.current).reduce((acc, arr) => acc + (Array.isArray(arr) ? arr.length : 0), 0);
        handleNmcUpdate(totalMappedNmcs, totalNmcCodes);
        errorLogRef.current = [...errorLogRef.current, ...e.data.errors];
        const processingTime = performance.now() - (performanceStartRef.current || 0);
        if (processingTime > 1000) {
          batchSizeRef.current = Math.max(1, batchSizeRef.current - 1);
        } else if (processingTime < 500) {
          batchSizeRef.current = Math.min(10, batchSizeRef.current + 1);
        }
        setTimeout(() => {
          performanceStartRef.current = performance.now();
          const nextStart = e.data.index + 1;
          const nextEnd = Math.min(nextStart + batchSizeRef.current, totalBricks);
          workerRef.current?.postMessage({
            brickData,
            nmcData,
            startIndex: nextStart,
            endIndex: nextEnd,
            pause: false,
            totalBricks,
            keywordToCategory,
            productToNmc,
            nmcByCategory,
            nmcByKeyTerm,
            initialSelections,
            existingSelections: currentSelectionsRef.current,
          });
        }, 50);
      }
    };
    performanceStartRef.current = performance.now();
    const initialEnd = Math.min(batchSizeRef.current, totalBricks);
    workerRef.current.postMessage({
      brickData,
      nmcData,
      startIndex: 0,
      endIndex: initialEnd,
      pause: false,
      totalBricks,
      keywordToCategory,
      productToNmc,
      nmcByCategory,
      nmcByKeyTerm,
      initialSelections,
      existingSelections: currentSelectionsRef.current,
    });
    return () => {
      workerRef.current?.terminate();
      URL.revokeObjectURL(workerUrl);
    };
  }, []); // Run once

  // Custom Active Shape for Pie Chart
  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;
    return (
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 10}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        style={{ transition: "all 0.3s ease" }}
      />
    );
  };

  // Custom Label for Enterprise Pie Chart
  const renderEnterpriseLabel = (props: any) => {
    const { cx, cy, midAngle, outerRadius, fill, payload, value, index } = props;
    const isActive = index === activeEnterpriseIndex;
    const RADIAN = Math.PI / 180;
    const sin = Math.sin(-RADIAN * midAngle);
    const cos = Math.cos(-RADIAN * midAngle);
    const sx = cx + (outerRadius + 10) * cos;
    const sy = cy + (outerRadius + 10) * sin;
    const mx = cx + (outerRadius + 30) * cos;
    const my = cy + (outerRadius + 30) * sin;
    const ex = mx + (cos >= 0 ? 1 : -1) * 22;
    const ey = my;
    const textAnchor = cos >= 0 ? "start" : "end";
    return (
      <g key={`label-${index}`} style={{ transform: isActive ? "scale(1.06)" : "scale(1)", transformOrigin: `${ex}px ${ey}px` }}>
        <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" strokeDasharray="3 3" strokeWidth={isActive ? 2 : 1} />
        <circle cx={ex} cy={ey} r="2" fill={fill} stroke="none" />
        <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#111827" fontSize={10} fontWeight={isActive ? "bold" : "normal"}>
          {payload.name}
        </text>
        <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey + 12} textAnchor={textAnchor} fill="#6B7280" fontSize={9}>
          {`${value} entité${value > 1 ? "s" : ""}`}
        </text>
      </g>
    );
  };

  // Container variants for cooler animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans scroll-smooth">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-950 to-blue-600 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 py-24 md:py-32 flex flex-col md:flex-row items-start gap-12">
          <motion.div
            className="flex-1 space-y-8 z-10"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.img
              src="https://edi-dev.codeonline-info.com/lovable-uploads/a13c1ffe-9c2c-4e6a-a048-063ce7274535.png"
              alt="Codeonline EDI Logo"
              className="h-24 w-auto object-contain"
              variants={itemVariants}
              onError={(e) => {
                e.currentTarget.src = "https://via.placeholder.com/384x96?text=Logo+Failed";
              }}
            />
            <motion.h1 
              className="text-5xl md:text-6xl font-bold tracking-tight leading-tight"
              variants={itemVariants}
            >
              Codeonline EDI
            </motion.h1>
            <motion.p 
              className="text-lg max-w-lg"
              variants={itemVariants}
            >
              Transformez vos processus métier avec une plateforme EDI intuitive, performante et sécurisée. Connectez, analysez et optimisez vos données en temps réel.
            </motion.p>
            <motion.div 
              className="flex items-center gap-4"
              variants={itemVariants}
            >
              <a
                href="/login"
                className="inline-block px-8 py-4 bg-white text-blue-900 font-semibold rounded-full shadow-lg hover:shadow-xl hover:bg-gray-100 transition transform hover:scale-105"
              >
                Se connecter
              </a>
              <a
                href="#features"
                className="inline-block px-8 py-4 bg-transparent border border-white text-white font-semibold rounded-full hover:bg-white hover:text-blue-900 transition"
              >
                En savoir plus
              </a>
            </motion.div>
          </motion.div>
          <motion.div
            className="flex-1 text-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            {isAuthenticated && !isLoadingUser && (
              <motion.div
                className="mx-auto mb-4 bg-white rounded-full shadow-lg w-28 h-28 flex items-center justify-center -mt-2"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.4, type: "spring", stiffness: 300 }}
              >
                <img
                  src={effectiveLogoSrc}
                  alt="Company Logo"
                  className="h-26 w-26 rounded-full object-contain"
                  onError={() => setLogoLoadError(true)}
                />
              </motion.div>
            )}
            <motion.div 
              className="p-8 bg-white rounded-3xl shadow-xl"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <motion.h2 
                className="text-xl font-semibold text-blue-900"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Entités Enregistrées
              </motion.h2>
              <motion.p 
                className="text-5xl md:text-6xl font-bold mt-4 text-blue-900"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                {entitiesCount.toLocaleString()}
              </motion.p>
              <motion.p 
                className="text-sm mt-2 text-blue-700"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                sur la plateforme Codeonline
              </motion.p>
            </motion.div>
          </motion.div>
        </div>
        <div className="absolute inset-0 " />
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-white" id="features">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-12"
            style={{ color: ACCENT }}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            Pourquoi choisir Codeonline EDI ?
          </motion.h2>
          <motion.div
            className="grid md:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {[
              { title: "Analyse Ultra-Rapide", desc: "Mappage et traitement des données en temps réel pour une efficacité optimale." },
              { title: "Visualisations Intuitives", desc: "Des graphiques dynamiques et interactifs pour une compréhension instantanée." },
              { title: "Fiabilité Assurée", desc: "Des résultats précis pour soutenir vos décisions stratégiques." },
            ].map((f, i) => (
              <motion.div
                key={i}
                className="p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-4"
                variants={itemVariants}
                whileHover={{ scale: 1.02 }}
              >
                <motion.h3 
                  className="text-2xl font-semibold mb-4" 
                  style={{ color: ACCENT }}
                >
                  {f.title}
                </motion.h3>
                <motion.p 
                  className="text-gray-600"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {f.desc}
                </motion.p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Dashboard Section with Progress Pies */}
      <section className="py-20 px-6 bg-white" id="dashboard">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-12"
            style={{ color: ACCENT }}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            Insights en Temps Réel
          </motion.h2>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div variants={itemVariants}>
              <Card className="bg-white border-none shadow-xl rounded-3xl overflow-hidden h-full">
                <CardHeader className="pb-3 bg-gradient-to-r from-blue-950 to-blue-600 text-white">
                  <h3 className="text-lg font-semibold">Rayons Mappés</h3>
                  <CardDescription className="text-sm text-white/90">
                    {mappingProgress}% ({mappedCount} sur {totalBricks})
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6 pb-8 p-4">
                  <ProgressPie value={mappedCount} maxValue={totalBricks} label="Rayons Mappés" />
                </CardContent>
              </Card>
            </motion.div>
            <motion.div variants={itemVariants}>
              <Card className="bg-white border-none shadow-xl rounded-3xl overflow-hidden h-full">
                <CardHeader className="pb-3 bg-gradient-to-r from-blue-950 to-blue-600 text-white">
                  <h3 className="text-lg font-semibold">Codes NMC Mappés</h3>
                  <CardDescription className="text-sm text-white/90">
                    {rayonData[0].value} sur {totalNmcCodes}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6 pb-8 p-4">
                  <ProgressPie value={rayonData[0].value} maxValue={totalNmcCodes} label="Codes Mappés" />
                </CardContent>
              </Card>
            </motion.div>
            <motion.div
              variants={itemVariants}
              className="md:col-span-2 lg:col-span-1"
            >
              <Card className="bg-white border-none shadow-xl rounded-3xl overflow-hidden h-full">
                <CardHeader className="pb-3 bg-gradient-to-r from-blue-950 to-blue-600 text-white">
                  <h3 className="text-lg font-semibold">Briques par Nombre de Rayons</h3>
                </CardHeader>
                <CardContent className="pt-6 pb-8 p-4">
                  <div className="h-[300px]">
                    <ResponsiveContainer>
                      <BarChart data={brickMappingData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value">
                          {brickMappingData.map((entry, index) => (
                            <Cell key={`cell-brick-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Sectors Section */}
      <section className="py-20 px-6 bg-white" id="sectors">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            className="text-4xl md:text-5xl font-bold text-center mb-12"
            style={{ color: ACCENT }}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            Analyse des Secteurs
          </motion.h2>
          <motion.div
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div variants={itemVariants}>
              <Card className="bg-white border-none shadow-xl rounded-3xl overflow-hidden h-full">
                <CardHeader className="pb-3 bg-gradient-to-r from-blue-950 to-blue-600 text-white">
                  <h3 className="text-lg font-semibold">Entités par Secteur</h3>
                </CardHeader>
                <CardContent className="pt-6 pb-8 p-4">
                  <div className="h-[420px]">
                    <ResponsiveContainer>
                      <PieChart>
                        <Pie
                          data={enterpriseData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={110}
                          activeIndex={activeEnterpriseIndex}
                          activeShape={renderActiveShape}
                          onMouseEnter={(_, index) => setActiveEnterpriseIndex(index)}
                          onMouseLeave={() => setActiveEnterpriseIndex(-1)}
                          label={renderEnterpriseLabel}
                          labelLine={false}
                        >
                          {enterpriseData.map((entry, index) => (
                            <Cell key={`cell-enterprise-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div variants={itemVariants}>
              <Card className="bg-white border-none shadow-xl rounded-3xl overflow-hidden h-full">
                <CardHeader className="pb-3 bg-gradient-to-r from-blue-950 to-blue-600 text-white">
                  <h3 className="text-lg font-semibold">Fiches Produit par Secteur</h3>
                </CardHeader>
                <CardContent className="pt-6 pb-8 p-4">
                  <div className="h-[420px]">
                    <ResponsiveContainer>
                      <BarChart data={productSheetData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value">
                          {productSheetData.map((entry, index) => (
                            <Cell key={`cell-product-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
          <motion.div
            className="mt-12"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-semibold mb-6" style={{ color: ACCENT }}>
              Entités par Secteur
            </h3>
            <motion.div 
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {enterpriseData.map((item, idx) => (
                <motion.div
                  key={idx}
                  className="flex items-start gap-3 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all transform hover:-translate-y-2"
                  variants={itemVariants}
                  whileHover={{ scale: 1.05 }}
                >
                  <span
                    className="mt-1 inline-block h-3 w-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <div>
                    <div className="font-medium text-gray-900">{item.name}</div>
                    <div className="text-sm text-gray-600">
                      {item.value} {item.value > 1 ? "entreprises" : "entreprise"}
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-6 bg-white" id="about">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            className="text-4xl md:text-5xl font-bold mb-6"
            style={{ color: ACCENT }}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            À propos de Codeonline EDI
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 leading-relaxed max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            Codeonline EDI est votre partenaire pour une gestion de données fluide et intelligente. Notre plateforme combine design moderne, analyses puissantes et une expérience utilisateur exceptionnelle pour transformer vos données en décisions stratégiques.
          </motion.p>
          <motion.div
            className="mt-8"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8, type: "spring" }}
          >
            <a
              href="/login"
              className="inline-block px-8 py-4 bg-blue-900 text-white font-semibold rounded-full shadow-lg hover:shadow-xl hover:bg-blue-800 transition transform hover:scale-110"
            >
              Commencer maintenant
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Index;