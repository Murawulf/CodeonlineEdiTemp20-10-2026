import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import axios from 'axios';
import { useNotifications } from '@/contexts/NotificationContext';

interface Profile {
  id_profile: number;
  role: string | null;
  id_entite: number | null;
  is_suspended: number;
  created_at: string;
  company_name: string | null;
  permissions: Permission[];
  email?: string | null;
  certicode?: string | null;
  created_by_Entite?: number;
}

interface Account {
  id_compte: number;
  id_entite: number;
  email: string;
  name: string | null;
  certicode: string | null;
  is_suspended: number;
  created_at: string;
  id_profile: number | null;
  permissions: Permission[];
}

interface Page {
  page_id: number;
  page_name: string;
}

interface Permission {
  page_id: number;
  page_name: string;
  read: boolean;
  write: boolean;
  hide: boolean;
  apercu?: boolean; // Only for Media page
  upload?: boolean; // Only for Media page
  delete_file?: boolean; // Only for Media page
  create_folder?: boolean; // Only for Media page
}

interface Company {
  id_entite: number;
  raison_socialle: string;
}

const API_BASE_URL = 'https://edi-dev.codeonline-info.com/api';

const Profile: React.FC = () => {
  const { addNotification } = useNotifications();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [pages, setPages] = useState<Page[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [suspendedAccounts, setSuspendedAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState({
    profiles: false,
    pages: false,
    companies: false,
    suspendedAccounts: false,
  });
  const [suspending, setSuspending] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [suspendedAccountsModalOpen, setSuspendedAccountsModalOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<Profile | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionMenuOpen, setActionMenuOpen] = useState<number | null>(null);
  const [menuPosition, setMenuPosition] = useState<{ top: number; left: number } | null>(null);
  const [currentTab, setCurrentTab] = useState<'Global' | 'TPO' | 'Entite'>('Global');
  const modalRef = useRef<HTMLDivElement>(null);
  const actionMenuRef = useRef<HTMLDivElement>(null);
  const suspendedAccountsModalRef = useRef<HTMLDivElement>(null);
  const [role, setRole] = useState('');
  const [idEntite, setIdEntite] = useState<number | null>(null);
  const [profileType, setProfileType] = useState<'model' | 'company' | null>(null);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [idCompte, setIdCompte] = useState<number | null>(null);
  const [userProducerName, setUserProducerName] = useState<string | null>(null);
  const [userIdEntite, setUserIdEntite] = useState<number | null>(null);
  const [isNetconsultingUser, setIsNetconsultingUser] = useState(false);
  const [allowEntitySelect, setAllowEntitySelect] = useState(true);
  const [fixedEntity, setFixedEntity] = useState<string | null>(null);

  const netconsultingId = useMemo(() =>
    companies.find(c => c.raison_socialle.toLowerCase() === 'netconsulting europe ltd')?.id_entite,
    [companies]
  );

  const cepexId = useMemo(() =>
    companies.find(c => c.raison_socialle.toLowerCase() === 'cepex')?.id_entite,
    [companies]
  );

  const netconsultingName = useMemo(() =>
    companies.find(c => c.raison_socialle.toLowerCase() === 'netconsulting europe ltd')?.raison_socialle,
    [companies]
  );

  const filteredCompaniesForSelect = useMemo(() =>
    companies.filter(c => c.id_entite !== netconsultingId && c.id_entite !== cepexId),
    [companies, netconsultingId, cepexId]
  );

  const parentKeywords = ['EDI', 'Produits', 'Paramètres'];

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        if (parsedUser.id_compte) {
          setIdCompte(parsedUser.id_compte);
          console.log('Profile: id_compte set to:', parsedUser.id_compte);
        } else {
          console.warn('Profile: id_compte missing in stored user:', parsedUser);
          addNotification('Utilisateur non authentifié, id_compte manquant', 'error');
        }
        if (parsedUser.id_entite) {
          setUserIdEntite(parsedUser.id_entite);
        }
        if (parsedUser.producer_name) {
          setUserProducerName(parsedUser.producer_name);
          setIsNetconsultingUser(parsedUser.producer_name.toLowerCase() === 'netconsulting europe ltd');
        }
      } catch (err) {
        console.error('Profile: Failed to parse stored user:', err);
        addNotification('Erreur lors du chargement de l\'utilisateur', 'error');
      }
    } else {
      console.warn('Profile: No user found in localStorage');
      addNotification('Aucun utilisateur connecté', 'error');
    }
  }, [addNotification]);

  const fetchProfiles = useCallback(async () => {
    try {
      setLoading(prev => ({ ...prev, profiles: true }));
      setError(null);
      const res = await axios.get<Profile[]>(`${API_BASE_URL}/profiles`, {
        withCredentials: true,
        timeout: 10000,
      });
      setProfiles(res.data);
      console.log('Profile: Profiles fetched successfully:', res.data);
    } catch (error: any) {
      const errorMessage =
        error.code === 'ECONNABORTED'
          ? 'Délai de connexion dépassé lors de la récupération des profils'
          : error.response?.data?.error || 'Échec de la récupération des profils';
      console.error('Profile: Failed to fetch profiles:', errorMessage);
      addNotification(errorMessage, 'error');
      setError(errorMessage);
    } finally {
      setLoading(prev => ({ ...prev, profiles: false }));
    }
  }, [addNotification]);

  const fetchPages = useCallback(async () => {
    try {
      setLoading(prev => ({ ...prev, pages: true }));
      setError(null);
      const res = await axios.get<Page[]>(`${API_BASE_URL}/pages`, {
        withCredentials: true,
        timeout: 10000,
      });
      setPages(res.data);
      setPermissions(
        res.data.map((page: Page) => ({
          page_id: page.page_id,
          page_name: page.page_name,
          read: false,
          write: false,
          hide: false,
          ...(page.page_name.toLowerCase() === 'media' ? {
            apercu: false,
            upload: false,
            delete_file: false,
            create_folder: false,
          } : {}),
        }))
      );
      console.log('Profile: Pages fetched successfully:', res.data);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des pages';
      console.error('Profile: Failed to fetch pages:', errorMessage);
      addNotification(errorMessage, 'error');
      setError(errorMessage);
    } finally {
      setLoading(prev => ({ ...prev, pages: false }));
    }
  }, [addNotification]);

  const fetchCompanies = useCallback(async () => {
    try {
      setLoading(prev => ({ ...prev, companies: true }));
      setError(null);
      const res = await axios.get<Company[]>(`${API_BASE_URL}/companies`, {
        withCredentials: true,
        timeout: 10000,
      });
      setCompanies(res.data);
      console.log('Profile: Companies fetched successfully:', res.data);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des entreprises';
      console.error('Profile: Failed to fetch companies:', errorMessage);
      addNotification(errorMessage, 'error');
      setError(errorMessage);
    } finally {
      setLoading(prev => ({ ...prev, companies: false }));
    }
  }, [addNotification]);

  const fetchSuspendedAccounts = useCallback(async (profileId: number) => {
    try {
      setLoading(prev => ({ ...prev, suspendedAccounts: true }));
      const res = await axios.get<Account[]>(`${API_BASE_URL}/comptes?profile_id=${profileId}&is_suspended=1`, {
        withCredentials: true,
        timeout: 10000,
      });
      setSuspendedAccounts(res.data);
      setSuspendedAccountsModalOpen(true);
      addNotification(`Comptes suspendus récupérés pour le profil ${profileId}`, 'success');
      console.log('Profile: Suspended accounts fetched for profileId:', profileId, res.data);
    } catch (error: any) {
      const errorMessage =
        error.code === 'ECONNABORTED'
          ? 'Délai de connexion dépassé lors de la récupération des comptes suspendus'
          : error.response?.data?.error || 'Échec de la récupération des comptes suspendus';
      console.error('Profile: Failed to fetch suspended accounts:', errorMessage);
      addNotification(errorMessage, 'error');
    } finally {
      setLoading(prev => ({ ...prev, suspendedAccounts: false }));
    }
  }, [addNotification]);

  useEffect(() => {
    fetchProfiles();
    fetchPages();
    fetchCompanies();
  }, [fetchProfiles, fetchPages, fetchCompanies]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        setModalOpen(false);
      }
      if (actionMenuRef.current && !actionMenuRef.current.contains(event.target as Node)) {
        setActionMenuOpen(null);
        setMenuPosition(null);
      }
      if (suspendedAccountsModalRef.current && !suspendedAccountsModalRef.current.contains(event.target as Node)) {
        setSuspendedAccountsModalOpen(false);
      }
    };
    if (modalOpen || actionMenuOpen !== null || suspendedAccountsModalOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [modalOpen, actionMenuOpen, suspendedAccountsModalOpen]);

  const resetForm = () => {
    setRole('');
    setIdEntite(null);
    setProfileType(null);
    setFixedEntity(null);
    setAllowEntitySelect(true);
    setPermissions(
      pages.map(page => ({
        page_id: page.page_id,
        page_name: page.page_name,
        read: false,
        write: false,
        hide: false,
        ...(page.page_name.toLowerCase() === 'media' ? {
          apercu: false,
          upload: false,
          delete_file: false,
          create_folder: false,
        } : {}),
      }))
    );
  };

  const openNewModal = (tab?: string | null) => {
    resetForm();
    setEditingProfile(null);
    if (isNetconsultingUser) {
      if (tab === 'Global' || tab === 'TPO') {
        setProfileType('company');
      } else if (tab === 'Entite') {
        setProfileType('model');
      }
      if (tab === 'Global') {
        setFixedEntity(netconsultingName || '');
        setIdEntite(netconsultingId || null);
        setAllowEntitySelect(false);
      } else if (tab === 'TPO') {
        setFixedEntity(companies.find(c => c.id_entite === cepexId)?.raison_socialle || 'CEPEX');
        setIdEntite(cepexId || null);
        setAllowEntitySelect(false);
      } else if (tab === 'Entite') {
        setFixedEntity('Tous');
        setIdEntite(null);
        setAllowEntitySelect(false);
      }
    } else {
      setProfileType(null);
      setFixedEntity(userProducerName || '');
      setIdEntite(userIdEntite || null);
      setAllowEntitySelect(false);
    }
    setModalOpen(true);
  };

  const handleProfileTypeChange = (type: 'model' | 'company') => {
    setProfileType(type);
    if (type === 'model') {
      setFixedEntity('Tous');
      setIdEntite(null);
      setAllowEntitySelect(false);
      setCurrentTab('Entite');
    } else {
      if (currentTab === 'TPO') {
        setFixedEntity(companies.find(c => c.id_entite === cepexId)?.raison_socialle || 'CEPEX');
        setIdEntite(cepexId || null);
      } else {
        setFixedEntity(netconsultingName || '');
        setIdEntite(netconsultingId || null);
      }
      setAllowEntitySelect(false);
    }
  };

  const openEditModal = (profile: Profile) => {
    setEditingProfile(profile);
    setRole(profile.role || '');
    setProfileType(null);
    setIdEntite(profile.id_entite);
    setFixedEntity(profile.company_name || '');
    setAllowEntitySelect(false);
    setPermissions(
      pages.map(page => {
        const perm = profile.permissions.find(p => p.page_id === page.page_id);
        return {
          page_id: page.page_id,
          page_name: page.page_name,
          read: perm ? !!perm.read : false,
          write: perm ? !!perm.write : false,
          hide: perm ? !!perm.hide : false,
          ...(page.page_name.toLowerCase() === 'media' ? {
            apercu: perm ? !!perm.apercu : false,
            upload: perm ? !!perm.upload : false,
            delete_file: perm ? !!perm.delete_file : false,
            create_folder: perm ? !!perm.create_folder : false,
          } : {}),
        };
      })
    );
    setModalOpen(true);
  };

  const handlePermissionChange = (pageId: number, field: keyof Permission) => {
    setPermissions(prev => {
      const newPermissions = [...prev];
      const index = newPermissions.findIndex(perm => perm.page_id === pageId);
      if (index === -1) return prev;
      const currentValue = newPermissions[index][field] as boolean;
      const newValue = !currentValue;
      newPermissions[index] = { ...newPermissions[index], [field]: newValue };
      const pageName = newPermissions[index].page_name;
      if (parentKeywords.some(keyword => keyword.toLowerCase() === pageName.toLowerCase())) {
        newPermissions.forEach((perm, i) => {
          if (perm.page_name.toLowerCase().startsWith(pageName.toLowerCase() + '/')) {
            newPermissions[i] = { ...perm, [field]: newValue };
          }
        });
      }
      return newPermissions;
    });
  };

  const handleSelectAllPermissions = () => {
    setPermissions(prev =>
      prev.map(perm => ({
        ...perm,
        read: true,
        write: true,
        hide: perm.hide,
        ...(perm.page_name.toLowerCase() === 'media' ? {
          apercu: true,
          upload: true,
          delete_file: true,
          create_folder: true,
        } : {}),
      }))
    );
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;
    if (!permissions.some(perm => 
      perm.read || perm.write || perm.hide ||
      (perm.page_name.toLowerCase() === 'media' && (perm.apercu || perm.upload || perm.delete_file || perm.create_folder))
    )) {
      addNotification('Au moins une permission doit être définie', 'error');
      return;
    }
    setIsSubmitting(true);
    setError(null);
    const createdBy = isNetconsultingUser ? netconsultingId : userIdEntite;
    const profileData = {
      id_entite: idEntite,
      role: role || null,
      created_by_Entite: createdBy,
      permissions: permissions.map(perm => ({
        page_id: perm.page_id,
        read: perm.read ? 1 : 0,
        write: perm.write ? 1 : 0,
        hide: perm.hide ? 1 : 0,
        ...(perm.page_name.toLowerCase() === 'media' ? {
          apercu: perm.apercu ? 1 : 0,
          upload: perm.upload ? 1 : 0,
          delete_file: perm.delete_file ? 1 : 0,
          create_folder: perm.create_folder ? 1 : 0,
        } : {}),
      })),
    };
    try {
      if (editingProfile) {
        await axios.put(
          `${API_BASE_URL}/profiles/${editingProfile.id_profile}`,
          profileData,
          { withCredentials: true, timeout: 10000 }
        );
        addNotification('Profil mis à jour avec succès', 'success');
        console.log('Profile: Profile updated successfully, id:', editingProfile.id_profile);
      } else {
        const response = await axios.post(`${API_BASE_URL}/profiles`, profileData, {
          withCredentials: true, timeout: 10000,
        });
        addNotification('Profil créé avec succès', 'success');
        console.log('Profile: Profile created successfully:', response.data);
      }
      setModalOpen(false);
      fetchProfiles();
    } catch (error: any) {
      const errorMessage =
        error.code === 'ECONNABORTED'
          ? 'Délai de connexion dépassé lors de l\'enregistrement du profil'
          : error.response?.data?.error + (error.response?.data?.details ? `: ${error.response.data.details}` : '') || 'Échec de l\'enregistrement du profil';
      console.error('Profile: Failed to save profile:', errorMessage);
      addNotification(errorMessage, 'error');
      setError(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSuspend = async (id: number, isSuspended: number) => {
    if (!window.confirm(`Voulez-vous vraiment ${isSuspended ? 'réactiver' : 'suspendre'} ce profil ?`)) return;
    setSuspending(id);
    try {
      await axios.patch(
        `${API_BASE_URL}/profiles/${id}/suspend`,
        { is_suspended: isSuspended ? 0 : 1 },
        { withCredentials: true, timeout: 10000 }
      );
      addNotification(`Profil ${isSuspended ? 'réactivé' : 'suspendu'} avec succès`, 'success');
      console.log('Profile: Profile status updated, id:', id, 'isSuspended:', isSuspended ? 0 : 1);
      fetchProfiles();
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.error || `Echec de la mise a jour du statut du profil ${id}`;
      console.error('Profile: Failed to update profile status:', errorMessage);
      addNotification(errorMessage, 'error');
      setError(errorMessage);
    } finally {
      setSuspending(null);
    }
  };

  const handleActionButtonClick = (profileId: number, event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const button = event.currentTarget;
    const rect = button.getBoundingClientRect();
    setMenuPosition({
      top: rect.bottom + window.scrollY + 4,
      left: rect.left + window.scrollX,
    });
    setActionMenuOpen(actionMenuOpen === profileId ? null : profileId);
  };

  const groupPermissions = (permissions: Permission[]) => {
    const groups: { [key: string]: Permission[] } = {};
    const ungrouped: Permission[] = [];
    permissions.forEach(perm => {
      const pageName = perm.page_name;
      let grouped = false;
      for (const keyword of parentKeywords) {
        if (pageName.toLowerCase() === keyword.toLowerCase()) {
          if (!groups[keyword]) {
            groups[keyword] = [perm];
          } else {
            groups[keyword].unshift(perm);
          }
          grouped = true;
          break;
        } else if (pageName.toLowerCase().startsWith(keyword.toLowerCase() + '/')) {
          if (!groups[keyword]) {
            groups[keyword] = [];
          }
          groups[keyword].push(perm);
          grouped = true;
          break;
        }
      }
      if (!grouped) {
        ungrouped.push(perm);
      }
    });
    const groupedPermissions: Permission[] = [];
    parentKeywords.forEach(keyword => {
      if (groups[keyword]) {
        groupedPermissions.push(...groups[keyword]);
      }
    });
    groupedPermissions.push(...ungrouped);
    return groupedPermissions;
  };

  const filteredProfiles = useMemo(() => {
    if (!isNetconsultingUser) return [];
    const netId = netconsultingId;
    if (!netId) return [];
    return profiles.filter(p => {
      if (currentTab === 'Global') {
        return p.id_entite === netId;
      }
      if (currentTab === 'TPO') {
        return p.id_entite === cepexId;
      }
      if (currentTab === 'Entite') {
        return p.id_entite === null && (p.created_by_Entite === netId || p.created_by_Entite === null);
      }
      return false;
    });
  }, [profiles, currentTab, isNetconsultingUser, netconsultingId, cepexId]);

  const models = useMemo(() => {
    const netId = netconsultingId;
    if (!netId || !userIdEntite) return [];
    return profiles.filter(p => p.created_by_Entite === netId && p.id_entite === null);
  }, [profiles, netconsultingId, userIdEntite]);

  const ownProfiles = useMemo(() => {
    if (!userIdEntite) return [];
    return profiles.filter(p => p.id_entite === userIdEntite && p.created_by_Entite === userIdEntite);
  }, [profiles, userIdEntite]);

  const isLoading = loading.profiles || loading.pages || loading.companies;

  const ProfilesTable = ({ profileList, title, showActions = true }: { profileList: Profile[]; title?: string; showActions?: boolean }) => (
    <div className="overflow-x-auto inline-block mx-auto">
      <table className="table-auto border-collapse border border-gray-200 shadow-sm">
        <thead>
          <tr className="bg-blue-950 text-white text-sm font-medium">
            <th className="border border-gray-200 p-3 text-center w-[80px]">ID</th>
            <th className="border border-gray-200 p-3 text-left max-w-[300px]">Nom Profil</th>
            <th className="border border-gray-200 p-3 text-left max-w-[300px]">Entité</th>
            <th className="border border-gray-200 p-3 text-center w-[120px]">Statut</th>
            {showActions && <th className="border border-gray-200 p-3 text-center w-[80px]">Actions</th>}
          </tr>
        </thead>
        <tbody>
          {profileList.length === 0 ? (
            <tr>
              <td colSpan={showActions ? 5 : 4} className="border border-gray-200 p-3 text-center text-gray-500">
                Aucun profil disponible
              </td>
            </tr>
          ) : (
            profileList.map((profile, index) => {
              const canManageProfile = isNetconsultingUser || profile.created_by_Entite === userIdEntite;
              const rowClass = `${profile.is_suspended ? 'bg-gray-100' : index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-gray-200 transition-colors`;
              return (
                <tr key={profile.id_profile} className={rowClass}>
                  <td className="border border-gray-200 p-3 text-center text-sm">
                    {profile.id_profile}
                  </td>
                  <td className="border border-gray-200 p-3 text-left text-sm max-w-[300px] truncate">
                    {profile.role || 'N/A'}
                  </td>
                  <td className="border border-gray-200 p-3 text-left text-sm max-w-[300px] truncate">
                    {profile.company_name || 'Tous'}
                  </td>
                  <td className="border border-gray-200 p-3 text-center text-sm">
                    {profile.is_suspended ? 'Suspendue' : 'Actif'}
                  </td>
                  {showActions && (
                    <td className="border border-gray-200 p-3 text-center">
                      {canManageProfile ? (
                        <>
                          <button
                            onClick={(e) => handleActionButtonClick(profile.id_profile, e)}
                            className={`px-3 py-1 bg-blue-950 text-white rounded hover:bg-blue-800 text-base ${
                              suspending === profile.id_profile ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                            disabled={suspending === profile.id_profile}
                            aria-label={`Ouvrir le menu d'actions pour le profil ${profile.id_profile}`}
                            aria-expanded={actionMenuOpen === profile.id_profile}
                          >
                            {suspending === profile.id_profile ? 'En cours...' : '☰'}
                          </button>
                          {actionMenuOpen === profile.id_profile && menuPosition && (
                            <div
                              ref={actionMenuRef}
                              className="fixed z-20 w-48 bg-white border border-gray-200 rounded shadow-lg"
                              style={{
                                top: `${menuPosition.top}px`,
                                left: `${menuPosition.left}px`,
                              }}
                              role="menu"
                            >
                              <button
                                onClick={() => openEditModal(profile)}
                                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem"
                              >
                                Modifier
                              </button>
                              <button
                                onClick={() => handleSuspend(profile.id_profile, profile.is_suspended)}
                                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem"
                              >
                                {profile.is_suspended ? 'Réactiver' : 'Suspendre'}
                              </button>
                              <button
                                onClick={() => fetchSuspendedAccounts(profile.id_profile)}
                                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                role="menuitem"
                                disabled={loading.suspendedAccounts}
                              >
                                {loading.suspendedAccounts ? 'Chargement...' : 'Comptes suspendus'}
                              </button>
                            </div>
                          )}
                        </>
                      ) : null}
                    </td>
                  )}
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );

  const renderSection = (title: string, profileList: Profile[], showActions = true) => (
    <div className="mb-6">
      <h4 className="text-lg font-medium mb-2 text-blue-950">{title}</h4>
      {profileList.length === 0 ? (
        <p className="text-gray-500">Aucun {title.toLowerCase().replace('modèles globaux', 'modèle global').replace('nos profils', 'profil')} disponible</p>
      ) : (
        <ProfilesTable profileList={profileList} showActions={showActions} />
      )}
    </div>
  );

  return (
    <div className="min-h-screen">
      <div className="p-6">
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px' }}>Paramètres / </span>
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px' }}>Profils</span>
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-4">
            {isNetconsultingUser ? (
              <div className="flex border-b">
                {['Global', 'TPO', 'Entite'].map(tab => (
                  <button
                    key={tab}
                    className={`px-4 py-2 capitalize text-base ${
                      currentTab === tab ? 'border-b-2 border-blue-950 text-blue-950 bg-blue-50' : 'text-gray-600 hover:bg-gray-100'
                    }`}
                    onClick={() => setCurrentTab(tab as 'Global' | 'TPO' | 'Entite')}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex border-b">
                <span className="px-4 py-2 capitalize text-base border-b-2 border-blue-950 text-blue-950 bg-blue-50">Nos Profiles</span>
              </div>
            )}
            <button
              onClick={() => openNewModal(isNetconsultingUser ? currentTab : null)}
              className="px-4 py-2 bg-blue-950 text-white rounded hover:bg-blue-800 text-sm font-medium"
              disabled={isLoading}
            >
              Ajouter profil
            </button>
          </div>
          <div className="mt-4 border-2 border-blue-950 rounded-lg p-4">
            {isLoading && <p className="text-gray-600">Chargement...</p>}
            {error && (
              <div className="p-6">
                <p className="text-red-600">{error}</p>
                <button
                  onClick={() => {
                    setError(null);
                    fetchProfiles();
                    fetchPages();
                    fetchCompanies();
                  }}
                  className="mt-2 bg-blue-950 text-white px-4 py-2 rounded hover:bg-blue-800"
                >
                  Réessayer
                </button>
              </div>
            )}
            {!isLoading && !error && (
              <>
                {isNetconsultingUser ? (
                  profiles.length === 0 ? (
                    <p>Aucun modèle de profil disponible</p>
                  ) : (
                    filteredProfiles.length === 0 ? (
                      <p>Aucun profil disponible</p>
                    ) : (
                      <ProfilesTable profileList={filteredProfiles} />
                    )
                  )
                ) : (
                  <>
                    {renderSection('Modèles Globaux', models, false)}
                    {renderSection('Nos Profils', ownProfiles, true)}
                  </>
                )}
              </>
            )}
            {modalOpen && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                <div ref={modalRef} className="bg-white p-6 rounded w-[600px] max-h-[90vh] overflow-auto">
                  <h2 className="text-xl font-medium mb-4 text-blue-950">
                    {editingProfile ? 'Modifier le modèle de profil' : 'Nouveau modèle de profil'}
                  </h2>
                  {isNetconsultingUser && !editingProfile && (
                    <div className="flex space-x-4 mb-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="profileType"
                          checked={profileType === 'model'}
                          onChange={() => handleProfileTypeChange('model')}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <span className="ml-2">Modèle de profil</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="profileType"
                          checked={profileType === 'company'}
                          onChange={() => handleProfileTypeChange('company')}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                        <span className="ml-2">Profil pour Netconsulting</span>
                      </label>
                    </div>
                  )}
                  <label className="block mb-2 font-medium text-gray-700">Entité</label>
                  {allowEntitySelect ? (
                    <select
                      className="w-full border border-gray-300 rounded p-2 mb-4"
                      value={idEntite || ''}
                      onChange={(e) => setIdEntite(Number(e.target.value) || null)}
                    >
                      <option value="">Sélectionner une entité</option>
                      {filteredCompaniesForSelect.map((company) => (
                        <option key={company.id_entite} value={company.id_entite}>
                          {company.raison_socialle}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="w-full border border-gray-300 rounded p-2 mb-4 bg-gray-100 text-gray-700">
                      {fixedEntity || 'N/A'}
                    </div>
                  )}
                  <label className="block mb-2 font-medium text-gray-700">Nom Profil</label>
                  <input
                    type="text"
                    className="w-full border border-gray-300 rounded p-2 mb-4"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="Optionnel"
                  />
                  <label className="block mb-2 font-medium text-gray-700">Permissions de profil</label>
                  <button
                    onClick={handleSelectAllPermissions}
                    className="mb-2 bg-blue-950 text-white px-4 py-2 rounded hover:bg-blue-800 text-sm"
                  >
                    Sélectionner toutes les permissions
                  </button>
                  <div className="mb-4">
                    {groupPermissions(permissions).map((perm) => {
                      const isSubpage = parentKeywords.some(keyword =>
                        perm.page_name.toLowerCase().startsWith(keyword.toLowerCase() + '/') &&
                        perm.page_name.toLowerCase() !== keyword.toLowerCase()
                      );
                      const isMediaPage = perm.page_name.toLowerCase() === 'media';
                      return (
                        <div
                          key={perm.page_id}
                          className={`flex items-center mb-2 ${isSubpage ? 'border-l-4 border-blue-500 pl-2' : ''}`}
                          style={{ marginLeft: isSubpage ? '20px' : '0' }}
                        >
                          <span className="w-1/3 text-sm">{perm.page_name}</span>
                          {isMediaPage ? (
                            <>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.apercu}
                                  onChange={() => handlePermissionChange(perm.page_id, 'apercu')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Aperçu</span>
                              </label>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.upload}
                                  onChange={() => handlePermissionChange(perm.page_id, 'upload')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Uploader</span>
                              </label>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.delete_file}
                                  onChange={() => handlePermissionChange(perm.page_id, 'delete_file')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Supprimer</span>
                              </label>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.create_folder}
                                  onChange={() => handlePermissionChange(perm.page_id, 'create_folder')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Créer dossier</span>
                              </label>
                            </>
                          ) : (
                            <>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.read}
                                  onChange={() => handlePermissionChange(perm.page_id, 'read')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Lire</span>
                              </label>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.write}
                                  onChange={() => handlePermissionChange(perm.page_id, 'write')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Éditer</span>
                              </label>
                              <label className="w-1/6 flex items-center">
                                <input
                                  type="checkbox"
                                  checked={perm.hide}
                                  onChange={() => handlePermissionChange(perm.page_id, 'hide')}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                />
                                <span className="ml-1 text-sm">Masquer</span>
                              </label>
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex justify-end space-x-4">
                    <button
                      onClick={() => setModalOpen(false)}
                      className="px-4 py-2 border border-gray-400 rounded hover:bg-gray-100"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={handleSubmit}
                      disabled={isSubmitting || (isNetconsultingUser && !editingProfile && !profileType)}
                      className={`px-4 py-2 bg-blue-950 text-white rounded ${
                        isSubmitting || (isNetconsultingUser && !editingProfile && !profileType) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-800'
                      }`}
                    >
                      {isSubmitting ? 'Enregistrement...' : editingProfile ? 'Mettre à jour' : 'Créer'}
                    </button>
                  </div>
                </div>
              </div>
            )}
            {suspendedAccountsModalOpen && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                <div ref={suspendedAccountsModalRef} className="bg-white p-6 rounded w-[600px] max-h-[90vh] overflow-auto">
                  <h2 className="text-xl font-medium mb-4 text-blue-950">Comptes Suspendus</h2>
                  {loading.suspendedAccounts ? (
                    <p className="text-gray-600">Chargement des comptes suspendus...</p>
                  ) : suspendedAccounts.length === 0 ? (
                    <p>Aucun compte suspendu trouvé pour ce profil.</p>
                  ) : (
                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-blue-950 text-white">
                          <th className="border border-gray-300 p-2 text-left">Identifiant</th>
                          <th className="border border-gray-300 p-2 text-left">Courriel</th>
                          <th className="border border-gray-300 p-2 text-left">Nom</th>
                          <th className="border border-gray-300 p-2 text-left">Entité</th>
                        </tr>
                      </thead>
                      <tbody>
                        {suspendedAccounts.map((account) => (
                          <tr key={account.id_compte} className="bg-gray-200">
                            <td className="border border-gray-300 p-2">{account.id_compte}</td>
                            <td className="border border-gray-300 p-2">{account.email}</td>
                            <td className="border border-gray-300 p-2">{account.name || 'N/A'}</td>
                            <td className="border border-gray-300 p-2">
                              {companies.find(c => c.id_entite === account.id_entite)?.raison_socialle || 'N/A'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                  <div className="flex justify-end mt-4">
                    <button
                      onClick={() => setSuspendedAccountsModalOpen(false)}
                      className="px-4 py-2 border border-gray-400 rounded hover:bg-gray-100"
                    >
                      Fermer
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;