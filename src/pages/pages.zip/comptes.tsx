import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import axios from 'axios';
import { useNotifications } from '@/contexts/NotificationContext';

// Type definitions for clarity and type safety
interface Account {
  id_compte: number;
  id_entite: number;
  email: string;
  name: string | null;
  prenom: string | null;
  certicode: string | null;
  is_suspended: number;
  created_at: string;
  profile_id: number | null;
  permissions: AccountPermission[];
  producer_name?: string | null;
}

interface AccountPermission {
  page_id: number;
  page_name?: string;
  read: boolean;
  write: boolean;
  hide: boolean;
}

interface Profile {
  id_profile: number;
  role: string | null;
  is_suspended: number;
  id_entite: number | null;
  company_name: string | null;
}

interface Page {
  page_id: number;
  page_name: string;
}

interface Company {
  id_entite: number;
  raison_socialle: string;
}

const API_BASE_URL = 'https://edi-dev.codeonline-info.com/api';

const Comptes: React.FC = () => {
  const { addNotification } = useNotifications();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [pages, setPages] = useState<Page[]>([]);
  const [permissions, setPermissions] = useState<AccountPermission[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [useCustomPermissions, setUseCustomPermissions] = useState(false);
  const [actionMenuOpen, setActionMenuOpen] = useState<number | null>(null);
  const [menuPosition, setMenuPosition] = useState<{ top: number; left: number } | null>(null);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [prenom, setPrenom] = useState('');
  const [idProducteur, setIdProducteur] = useState<number | ''>('');
  const [profileId, setProfileId] = useState<number | ''>('');
  const [loading, setLoading] = useState(false);
  const [suspending, setSuspending] = useState<number | null>(null);
  const [isInitialFetch, setIsInitialFetch] = useState(true);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Account | 'raison_socialle' | 'profile' | null;
    direction: 'ASC' | 'DESC' | null;
  }>({
    key: null,
    direction: null,
  });
  const [idCompte, setIdCompte] = useState<number | null>(null);
  const [userIdProducteur, setUserIdProducteur] = useState<number | null>(null);
  const [isNetconsultingUser, setIsNetconsultingUser] = useState(false);
  const [userProducerName, setUserProducerName] = useState<string | null>(null);
  const [userAccount, setUserAccount] = useState<Account | null>(null);
  const [dataLoaded, setDataLoaded] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const actionMenuRef = useRef<HTMLDivElement>(null);
  const buttonRefs = useRef<Map<number, HTMLButtonElement>>(new Map());

  const parentKeywords = ['EDI', 'Produits', 'Paramètres'];

  const isAdminUser = useMemo(() => {
    if (isNetconsultingUser) return true;
    if (!userAccount?.profile_id) return false;
    const profile = profiles.find((p) => p.id_profile === userAccount.profile_id);
    if (!profile) return false;
    const roleLower = profile.role?.toLowerCase() || '';
    const adminKeywords = ['superviseur', 'admin'];
    return adminKeywords.some((kw) => roleLower.includes(kw));
  }, [isNetconsultingUser, userAccount, profiles]);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        if (parsedUser.id_compte) {
          setIdCompte(parsedUser.id_compte);
          console.log('Comptes: id_compte set to:', parsedUser.id_compte);
        } else {
          console.warn('Comptes: id_compte missing in stored user:', parsedUser);
          addNotification('Utilisateur non authentifié, id_compte manquant', 'error');
        }
        if (parsedUser.id_entite) {
          setUserIdProducteur(parsedUser.id_entite);
        }
        if (parsedUser.producer_name) {
          setUserProducerName(parsedUser.producer_name);
          const lowerProducerName = parsedUser.producer_name.toLowerCase().trim();
          setIsNetconsultingUser(lowerProducerName.includes('netconsulting europe ltd'));
          console.log('Comptes: producer_name:', lowerProducerName);
          console.log('Comptes: isNetconsultingUser set to:', lowerProducerName.includes('netconsulting europe ltd'));
        }
      } catch (err) {
        console.error('Comptes: Failed to parse stored user:', err);
        addNotification('Erreur lors du chargement de l\'utilisateur', 'error');
      }
    } else {
      console.warn('Comptes: No user found in localStorage');
      addNotification('Aucun utilisateur connecté', 'error');
    }
  }, [addNotification]);

  const fetchUserAccount = useCallback(async () => {
    if (!idCompte) return;
    try {
      const res = await axios.get<Account>(`${API_BASE_URL}/comptes/${idCompte}`, { withCredentials: true });
      setUserAccount(res.data);
      console.log('Comptes: User account fetched:', res.data);
    } catch (error: any) {
      console.error('Comptes: Error fetching user account:', error);
      addNotification('Erreur lors du chargement du compte utilisateur', 'error');
    }
  }, [idCompte, addNotification]);

  useEffect(() => {
    if (idCompte && !userAccount) {
      fetchUserAccount();
    }
  }, [idCompte, userAccount, fetchUserAccount]);

  const groupPermissions = (permissions: AccountPermission[]): AccountPermission[] => {
    const groups: { [key: string]: AccountPermission[] } = {};
    const ungrouped: AccountPermission[] = [];

    permissions.forEach((perm) => {
      const pageName = perm.page_name || `Page ${perm.page_id}`;
      let grouped = false;

      for (const keyword of parentKeywords) {
        if (pageName.toLowerCase() === keyword.toLowerCase()) {
          if (!groups[keyword]) {
            groups[keyword] = [perm];
          } else {
            groups[keyword].unshift(perm);
          }
          grouped = true;
          break;
        } else if (pageName.toLowerCase().startsWith(keyword.toLowerCase() + '/')) {
          if (!groups[keyword]) {
            groups[keyword] = [];
          }
          groups[keyword].push(perm);
          grouped = true;
          break;
        }
      }

      if (!grouped) {
        ungrouped.push(perm);
      }
    });

    const groupedPermissions: AccountPermission[] = [];
    parentKeywords.forEach((keyword) => {
      if (groups[keyword]) {
        groupedPermissions.push(...groups[keyword]);
      }
    });
    groupedPermissions.push(...ungrouped);

    return groupedPermissions;
  };

  const fetchProfiles = useCallback(async () => {
    try {
      const res = await axios.get<Profile[]>(`${API_BASE_URL}/profiles`, { withCredentials: true });
      setProfiles(res.data);
      if (res.data.length === 0 || !res.data.some((p) => p.id_profile === 8)) {
        console.warn('Comptes: Profile ID 8 not found in profiles, using default profileId=8');
        addNotification('Aucun profil trouvé ou ID 8 manquant', 'error');
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des profils';
      console.error('Comptes: Error fetching profiles:', errorMessage);
      addNotification(errorMessage, 'error');
    }
  }, [addNotification]);

  const fetchCompanies = useCallback(async () => {
    try {
      const res = await axios.get<Company[]>(`${API_BASE_URL}/companies`, { withCredentials: true });
      setCompanies(res.data);
      if (res.data.length === 0 || !res.data.some((c) => c.id_entite === 1)) {
        console.warn('Comptes: Company ID 1 not found in companies, using default idProducteur=1');
        addNotification('Aucune entreprise trouvée ou ID 1 manquant', 'error');
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des entreprises';
      console.error('Comptes: Error fetching companies:', errorMessage);
      addNotification(errorMessage, 'error');
    }
  }, [addNotification]);

  const fetchPages = useCallback(async () => {
    try {
      const res = await axios.get<Page[]>(`${API_BASE_URL}/pages`, { withCredentials: true });
      setPages(res.data);
      setPermissions(
        res.data.map((page) => ({
          page_id: page.page_id,
          page_name: page.page_name,
          read: false,
          write: false,
          hide: false,
        }))
      );
      console.log('Comptes: Pages fetched successfully:', res.data);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des pages';
      console.error('Comptes: Error fetching pages:', errorMessage);
      addNotification(errorMessage, 'error');
    }
  }, [addNotification]);

  const fetchAccounts = useCallback(async () => {
    try {
      setLoading(true);
      const res = await axios.get<Account[]>(`${API_BASE_URL}/comptes`, { withCredentials: true });
      let filteredAccounts = res.data;

      console.log('Comptes: Raw accounts from API:', res.data.length);
      console.log('Comptes: isNetconsultingUser:', isNetconsultingUser);
      console.log('Comptes: isAdminUser:', isAdminUser);
      console.log('Comptes: userIdProducteur:', userIdProducteur);
      console.log('Comptes: idCompte:', idCompte);

      if (!isNetconsultingUser) {
        // Apply profile suspension filter only for non-Netconsulting users
        filteredAccounts = filteredAccounts.filter((account) => {
          if (!account.profile_id) return true;
          const profile = profiles.find((p) => p.id_profile === account.profile_id);
          return profile && profile.is_suspended === 0;
        });
        console.log('Comptes: After profile filter:', filteredAccounts.length);

        // Then apply entity/user filter - always filter to entity for non-Netconsulting users (assuming all entity users see entity accounts)
        if (userIdProducteur) {
          filteredAccounts = filteredAccounts.filter((account) => account.id_entite === userIdProducteur);
          console.log('Comptes: Filtered to entity accounts:', filteredAccounts.length);
        } else {
          filteredAccounts = filteredAccounts.filter((account) => account.id_compte === idCompte);
          console.log('Comptes: Filtered to own account (no entity):', filteredAccounts.length);
        }
      } else {
        // For Netconsulting, show all accounts without any filtering
        console.log('Comptes: Netconsulting user - showing ALL accounts (no filters applied):', filteredAccounts.length);
        // Explicitly do not apply profile filter for Netconsulting
      }

      setAccounts(filteredAccounts);
      setDataLoaded(true);
      console.log('Comptes: Final accounts set:', filteredAccounts.length);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des comptes';
      console.error('Comptes: Error fetching accounts:', errorMessage);
      addNotification(errorMessage, 'error');
    } finally {
      setLoading(false);
    }
  }, [profiles, addNotification, isNetconsultingUser, userIdProducteur, isAdminUser, idCompte]);

  useEffect(() => {
    if (isInitialFetch) {
      Promise.all([fetchProfiles(), fetchCompanies(), fetchPages()])
        .then(() => {
          setIsInitialFetch(false);
          console.log('Comptes: Initial fetch completed');
        })
        .catch((error) => {
          console.error('Comptes: Error during initial fetch:', error);
          addNotification('Échec du chargement initial des données', 'error');
        });
    }
  }, [fetchProfiles, fetchCompanies, fetchPages, isInitialFetch, addNotification]);

  // Separate useEffect to ensure fetchAccounts is called after user data is loaded
  useEffect(() => {
    if (!isInitialFetch && !dataLoaded) {
      fetchAccounts();
    }
  }, [fetchAccounts, isInitialFetch, dataLoaded]);

  // Re-fetch when isNetconsultingUser changes to ensure correct filtering
  useEffect(() => {
    if (!isInitialFetch && dataLoaded) {
      fetchAccounts();
    }
  }, [isNetconsultingUser]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        setModalOpen(false);
      }
      if (actionMenuRef.current && !actionMenuRef.current.contains(event.target as Node)) {
        setActionMenuOpen(null);
        setMenuPosition(null);
      }
    };
    if (modalOpen || actionMenuOpen !== null) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [modalOpen, actionMenuOpen]);

  const resetForm = () => {
    setEmail('');
    setName('');
    setPrenom('');
    setIdProducteur('');
    setProfileId('');
    setUseCustomPermissions(false);
    setPermissions(
      pages.map((page) => ({
        page_id: page.page_id,
        page_name: page.page_name,
        read: false,
        write: false,
        hide: false,
      }))
    );
  };

  const openNewModal = () => {
    setEditingAccount(null);
    resetForm();
    if (!isNetconsultingUser && userIdProducteur) {
      setIdProducteur(userIdProducteur);
    }
    setModalOpen(true);
  };

  const openEditModal = async (account: Account) => {
    setEditingAccount(account);
    setEmail(account.email);
    setName(account.name || '');
    setPrenom(account.prenom || '');
    setIdProducteur(account.id_entite);
    setProfileId(account.profile_id || '');
    setUseCustomPermissions(account.profile_id === null);

    try {
      const res = await axios.get<AccountPermission[]>(
        `${API_BASE_URL}/account-permissions/${account.id_compte}`,
        { withCredentials: true }
      );
      const perms = pages.map((page) => {
        const perm = res.data.find((p) => p.page_id === page.page_id);
        return {
          page_id: page.page_id,
          page_name: page.page_name,
          read: perm?.read || false,
          write: perm?.write || false,
          hide: perm?.hide || false,
        };
      });
      setPermissions(perms);
      console.log('Comptes: Account permissions fetched for id_compte:', account.id_compte);
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Échec de la récupération des permissions du compte';
      console.error('Comptes: Error fetching account permissions:', errorMessage);
      addNotification(errorMessage, 'error');
    }
    setModalOpen(true);
  };

  const handlePermissionChange = (pageId: number, field: 'read' | 'write' | 'hide') => {
    setPermissions((prev) =>
      prev.map((perm) =>
        perm.page_id === pageId ? { ...perm, [field]: !perm[field] } : perm
      )
    );
  };

  const handleSelectAllPermissions = () => {
    setPermissions((prev) =>
      prev.map((perm) => ({
        ...perm,
        read: true,
        write: true,
        hide: perm.hide,
      }))
    );
  };

  const handleCustomPermissionsChange = (checked: boolean) => {
    setUseCustomPermissions(checked);
    if (checked) {
      setProfileId('');
    } else {
      setProfileId('');
    }
  };

  const handleProfileChange = (value: string) => {
    setProfileId(value ? Number(value) : '');
    if (value) {
      setUseCustomPermissions(false);
    }
  };

  const handleEntityChange = (value: string) => {
    if (isNetconsultingUser) {
      setIdProducteur(value ? Number(value) : '');
    }
    // For non-Netconsulting, do not allow change
  };

  const generateRandomPassword = () => {
    const length = 12;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
  };

  const handleSendConnectionInfo = async (account: Account) => {
    try {
      const newPassword = generateRandomPassword();
      const payload = {
        email: account.email,
        password: newPassword,
      };

      let permissions = [];
      const res = await axios.get<AccountPermission[]>(
        `${API_BASE_URL}/account-permissions/${account.id_compte}`,
        { withCredentials: true }
      );
      permissions = res.data.map((perm) => ({
        page_id: perm.page_id,
        read: perm.read ? 1 : 0,
        write: perm.write ? 1 : 0,
        hide: perm.hide ? 1 : 0,
      }));

      await axios.post(`${API_BASE_URL}/send-connection-info`, payload, {
        withCredentials: true,
      });

      const updatePayload = {
        email: account.email,
        certicode: null,
        password: newPassword,
        id_entite: account.id_entite || 1,
        profile_id: account.profile_id || 8,
        useCustomPermissions: account.profile_id === null,
        permissions: account.profile_id ? [] : permissions,
      };
      await axios.put(`${API_BASE_URL}/comptes/${account.id_compte}`, updatePayload, {
        withCredentials: true,
      });

      addNotification('Fiche de connexion envoyée avec succès', 'success');
      console.log('Comptes: Connection info sent for id_compte:', account.id_compte);
      fetchAccounts();
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Erreur lors de l\'envoi de la fiche de connexion';
      console.error('Comptes: Error in handleSendConnectionInfo:', {
        message: error.message,
        response: error.response?.data,
        accountId: account.id_compte,
        email: account.email,
      });
      addNotification(errorMessage, 'error');
    }
  };

  const handleSubmit = async () => {
    if (!email) {
      addNotification("L'email est requis", 'error');
      return;
    }
    if (useCustomPermissions && permissions.every((p) => !p.read && !p.write && !p.hide)) {
      addNotification('Veuillez définir au moins une permission personnalisée', 'error');
      return;
    }

    const payload = {
      id_entite: idProducteur || 1,
      email,
      name: name || null,
      prenom: prenom || null,
      profile_id: useCustomPermissions ? null : profileId || 8,
      useCustomPermissions,
      ...(useCustomPermissions && {
        permissions: permissions.map((p) => ({
          page_id: p.page_id,
          read: p.read ? 1 : 0,
          write: p.write ? 1 : 0,
          hide: p.hide ? 1 : 0,
        })),
      }),
    };

    try {
      if (editingAccount) {
        await axios.put(`${API_BASE_URL}/comptes/${editingAccount.id_compte}`, payload, {
          withCredentials: true,
        });
        addNotification('Compte mis à jour avec succès', 'success');
        console.log('Comptes: Account updated, id_compte:', editingAccount.id_compte);
      } else {
        await axios.post(`${API_BASE_URL}/comptes`, payload, { withCredentials: true });
        addNotification('Compte créé avec succès', 'success');
        console.log('Comptes: Account created, email:', email);
      }
      setModalOpen(false);
      fetchAccounts();
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Erreur lors de la sauvegarde';
      const errorDetails = error.response?.data?.details ? `: ${error.response.data.details}` : '';
      console.error('Comptes: Error in handleSubmit:', {
        message: error.message,
        response: error.response?.data,
        payload,
      });
      addNotification(`${errorMessage}${errorDetails}`, 'error');
    }
  };

  const handleSuspend = async (id: number, isSuspended: number) => {
    try {
      setSuspending(id);
      await axios.patch(
        `${API_BASE_URL}/comptes/${id}/suspend`,
        { is_suspended: isSuspended ? 0 : 1 },
        { withCredentials: true }
      );
      addNotification(`Compte ${isSuspended ? 'réactivé' : 'suspendu'} avec succès`, 'success');
      console.log('Comptes: Account status updated, id_compte:', id, 'isSuspended:', isSuspended ? 0 : 1);
      fetchAccounts();
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Erreur de suspension';
      console.error('Comptes: Error suspending account:', errorMessage);
      addNotification(errorMessage, 'error');
    } finally {
      setSuspending(null);
    }
  };

  const handleActionButtonClick = (accountId: number, event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const button = event.currentTarget;
    buttonRefs.current.set(accountId, button);
    const rect = button.getBoundingClientRect();
    const menuWidth = 192; // w-48 = 12rem = 192px
    const menuHeight = 150; // Approximate height of the menu
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Calculate horizontal position (viewport-relative)
    let menuLeft = rect.left;
    if (menuLeft + menuWidth > viewportWidth) {
      menuLeft = rect.right - menuWidth;
    }
    if (menuLeft < 0) {
      menuLeft = 8;
    }

    // Calculate vertical position (viewport-relative)
    let menuTop = rect.bottom + 4;
    if (menuTop + menuHeight > viewportHeight) {
      menuTop = rect.top - menuHeight - 4;
    }
    if (menuTop < 0) {
      menuTop = 8;
    }

    setMenuPosition({ top: menuTop, left: menuLeft });
    setActionMenuOpen(actionMenuOpen === accountId ? null : accountId);
  };

  const handleSort = (key: keyof Account | 'raison_socialle' | 'profile') => {
    setSortConfig((prev) => {
      const isSameKey = prev.key === key;
      const direction = isSameKey && prev.direction === 'ASC' ? 'DESC' : 'ASC';

      setAccounts((prevAccounts) => {
        const sortedAccounts = [...prevAccounts];
        sortedAccounts.sort((a, b) => {
          let aValue: any;
          let bValue: any;

          if (key === 'raison_socialle') {
            aValue = companies.find((c) => c.id_entite === a.id_entite)?.raison_socialle || '';
            bValue = companies.find((c) => c.id_entite === b.id_entite)?.raison_socialle || '';
          } else if (key === 'is_suspended') {
            aValue = a[key] ? 'Suspendue' : 'Actif';
            bValue = b[key] ? 'Suspendue' : 'Actif';
          } else if (key === 'profile') {
            aValue = profiles.find((p) => p.id_profile === a.profile_id)?.role || (a.profile_id === null ? 'Permissions personnalisées' : 'N/A');
            bValue = profiles.find((p) => p.id_profile === b.profile_id)?.role || (b.profile_id === null ? 'Permissions personnalisées' : 'N/A');
          } else if (key === 'name') {
            aValue = ((a.name || '') + ' ' + (a.prenom || '')).trim();
            bValue = ((b.name || '') + ' ' + (b.prenom || '')).trim();
          } else if (key === 'prenom') {
            aValue = a.prenom || '';
            bValue = b.prenom || '';
          } else {
            aValue = a[key] || '';
            bValue = b[key] || '';
          }

          if (aValue === '' && bValue !== '') return 1;
          if (bValue === '' && aValue !== '') return -1;
          if (aValue === '' && bValue === '') return 0;

          if (typeof aValue === 'string') {
            aValue = aValue.toLowerCase();
            bValue = bValue.toLowerCase();
          }

          const compare = (x: any, y: any) => {
            if (x < y) return direction === 'ASC' ? -1 : 1;
            if (x > y) return direction === 'ASC' ? 1 : -1;
            return 0;
          };

          return compare(aValue, bValue);
        });
        return sortedAccounts;
      });

      return { key, direction };
    });
  };

  const currentEntityId = useMemo(() => {
    let entityId: number | null = editingAccount?.id_entite ?? null;
    if (!entityId && idProducteur) {
      entityId = Number(idProducteur);
    }
    if (entityId === 0) entityId = null;
    return entityId;
  }, [editingAccount, idProducteur]);

  const filteredProfilesForSelect = useMemo(() => {
    const entityId = currentEntityId;
    return profiles.filter((p) => {
      if (p.is_suspended !== 0) return false;
      if (entityId === null) {
        return p.id_entite === null;
      }
      return p.id_entite === null || p.id_entite === entityId;
    });
  }, [profiles, currentEntityId]);

  return (
    <div className="min-h-screen">
      <div className="p-6">
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px' }}>Paramètres / </span>
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px' }}>Comptes</span>

        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={openNewModal}
              className="px-4 py-2 bg-blue-950 text-white rounded-lg hover:bg-blue-800 text-sm font-medium transition-colors"
            >
              Ajouter
            </button>
          </div>

          {loading ? (
            <p className="text-center text-gray-600 text-sm">Chargement des comptes...</p>
          ) : accounts.length === 0 ? (
            <p className="text-center text-gray-600 text-sm">Aucun compte disponible</p>
          ) : (
            <div className="bg-white shadow-lg rounded-lg overflow-hidden">
              <table className="w-full border-collapse">
                <thead className="bg-blue-950 text-white text-sm font-medium">
                  <tr>
                    <th
                      className="p-4 text-center w-[10%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('profile')}
                    >
                      Nom Profil
                      {sortConfig.key === 'profile' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th
                      className="p-4 text-left w-[25%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('email')}
                    >
                      Email
                      {sortConfig.key === 'email' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th
                      className="p-4 text-left w-[15%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('name')}
                    >
                      Nom
                      {sortConfig.key === 'name' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th
                      className="p-4 text-left w-[15%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('prenom')}
                    >
                      Prénom
                      {sortConfig.key === 'prenom' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th
                      className="p-4 text-left w-[20%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('raison_socialle')}
                    >
                      Entité
                      {sortConfig.key === 'raison_socialle' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th
                      className="p-4 text-center w-[10%] cursor-pointer hover:bg-blue-800 transition-colors"
                      onClick={() => handleSort('is_suspended')}
                    >
                      Statut
                      {sortConfig.key === 'is_suspended' && (
                        <span className="ml-1 text-white font-bold">
                          {sortConfig.direction === 'ASC' ? '↑' : '↓'}
                        </span>
                      )}
                    </th>
                    <th className="p-4 text-center w-[10%]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {accounts.map((account, index) => (
                    <tr
                      key={account.id_compte}
                      className={`${account.is_suspended
                        ? 'bg-gray-200'
                        : index % 2 === 0
                        ? 'bg-white'
                        : 'bg-gray-50'
                      } hover:bg-blue-50 transition-colors`}
                    >
                      <td className="border-t border-gray-200 p-4 text-center text-sm">
                        {profiles.find((p) => p.id_profile === account.profile_id)?.role || (account.profile_id === null ? 'Permissions personnalisées' : 'N/A')}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-left text-sm max-w-[300px] break-words">
                        {account.email}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-left text-sm max-w-[150px] break-words">
                        {account.name || 'N/A'}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-left text-sm max-w-[150px] break-words">
                        {account.prenom || 'N/A'}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-left text-sm max-w-[250px] break-words">
                        {companies.find((c) => c.id_entite === account.id_entite)
                          ?.raison_socialle || account.producer_name || 'N/A'}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-center text-sm">
                        {account.is_suspended ? 'Suspendue' : 'Actif'}
                      </td>
                      <td className="border-t border-gray-200 p-4 text-center">
                        <button
                          onClick={(e) => handleActionButtonClick(account.id_compte, e)}
                          className={`px-3 py-1 bg-blue-950 text-white rounded-lg hover:bg-blue-800 transition-colors text-lg font-medium ${
                            suspending === account.id_compte ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                          disabled={suspending === account.id_compte}
                          aria-label={`Ouvrir le menu d'actions pour le compte ${account.id_compte}`}
                          aria-expanded={actionMenuOpen === account.id_compte}
                        >
                          {suspending === account.id_compte ? 'En cours...' : '☰'}
                        </button>
                        {actionMenuOpen === account.id_compte && menuPosition && (
                          <div
                            ref={actionMenuRef}
                            className="fixed z-30 w-48 bg-white border border-gray-200 rounded-lg shadow-xl"
                            style={{ top: `${menuPosition.top}px`, left: `${menuPosition.left}px` }}
                            role="menu"
                          >
                            <button
                              onClick={() => openEditModal(account)}
                              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-100 hover:text-blue-950 transition-colors"
                              role="menuitem"
                            >
                              Modifier
                            </button>
                            <button
                              onClick={() => handleSuspend(account.id_compte, account.is_suspended)}
                              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-100 hover:text-blue-950 transition-colors"
                              role="menuitem"
                            >
                              {account.is_suspended ? 'Réactiver' : 'Suspendre'}
                            </button>
                            <button
                              onClick={() => handleSendConnectionInfo(account)}
                              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-100 hover:text-blue-950 transition-colors"
                              role="menuitem"
                            >
                              Envoyer fiche connexion
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {modalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div
              ref={modalRef}
              className="bg-white rounded-lg p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto scrollbar-custom"
            >
              <h2 className="text-xl font-semibold mb-6 text-blue-950">
                {editingAccount ? 'Modifier le compte' : 'Créer un nouveau compte'}
              </h2>

              <label className="block mb-2 text-sm font-medium text-gray-700">Entité</label>
              <select
                className="w-full border border-gray-300 rounded-lg p-2 mb-4 focus:ring-2 focus:ring-blue-950 focus:border-blue-950"
                value={idProducteur}
                onChange={(e) => handleEntityChange(e.target.value)}
                disabled={!isNetconsultingUser}
              >
                <option value="">Sélectionner une entité (par défaut: ID 1)</option>
                {companies.map((company) => (
                  <option key={company.id_entite} value={company.id_entite}>
                    {company.raison_socialle}
                  </option>
                ))}
              </select>

              <label className="block mb-2 text-sm font-medium text-gray-700">Email</label>
              <input
                type="email"
                className="w-full border border-gray-300 rounded-lg p-2 mb-4 focus:ring-2 focus:ring-blue-950 focus:border-blue-950"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Entrez le courriel"
                required
              />

              <label className="block mb-2 text-sm font-medium text-gray-700">Nom</label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg p-2 mb-4 focus:ring-2 focus:ring-blue-950 focus:border-blue-950"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Facultatif"
              />

              <label className="block mb-2 text-sm font-medium text-gray-700">Prénom</label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg p-2 mb-4 focus:ring-2 focus:ring-blue-950 focus:border-blue-950"
                value={prenom}
                onChange={(e) => setPrenom(e.target.value)}
                placeholder="Facultatif"
              />

              <label className="block mb-2 text-sm font-medium text-gray-700">Profil</label>
              <select
                className="w-full border border-gray-300 rounded-lg p-2 mb-4 focus:ring-2 focus:ring-blue-950 focus:border-blue-950"
                value={profileId}
                onChange={(e) => handleProfileChange(e.target.value)}
                disabled={useCustomPermissions}
              >
                <option value="">Sélectionner un profil (par défaut: ID 8)</option>
                {filteredProfilesForSelect.map((profile) => (
                  <option key={profile.id_profile} value={profile.id_profile}>
                    {profile.role || `Profil ${profile.id_profile}`}
                  </option>
                ))}
              </select>

              <label className="flex items-center mb-4">
                <input
                  type="checkbox"
                  checked={useCustomPermissions}
                  onChange={(e) => handleCustomPermissionsChange(e.target.checked)}
                  className="h-4 w-4 text-blue-950 border-gray-300 rounded focus:ring-blue-950"
                />
                <span className="ml-2 text-sm text-gray-700">Utiliser des permissions personnalisées</span>
              </label>

              {useCustomPermissions && (
                <>
                  <label className="block mb-2 text-sm font-medium text-gray-700">
                    Permissions personnalisées
                  </label>
                  <button
                    onClick={handleSelectAllPermissions}
                    className="mb-4 px-3 py-1 bg-blue-950 text-white rounded-lg hover:bg-blue-800 transition-colors text-sm font-medium"
                  >
                    Sélectionner toutes les permissions (Lire/Écrire)
                  </button>
                  <div className="mb-4 pl-2">
                    {groupPermissions(permissions).map((perm) => {
                      const pageName = perm.page_name || `Page ${perm.page_id}`;
                      const isSubpage = parentKeywords.some(
                        (keyword) =>
                          pageName.toLowerCase().startsWith(keyword.toLowerCase() + '/') &&
                          pageName.toLowerCase() !== keyword.toLowerCase()
                      );
                      return (
                        <div
                          key={perm.page_id}
                          className="flex items-center mb-2"
                          style={{ marginLeft: isSubpage ? '20px' : '0' }}
                        >
                          <span className="w-1/3 text-sm text-gray-700">{pageName}</span>
                          <label className="w-1/6 flex items-center">
                            <input
                              type="checkbox"
                              checked={perm.read}
                              onChange={() => handlePermissionChange(perm.page_id, 'read')}
                              className="h-4 w-4 text-blue-950 border-gray-300 rounded focus:ring-blue-950"
                            />
                            <span className="ml-1 text-sm text-gray-700">Lire</span>
                          </label>
                          <label className="w-1/6 flex items-center">
                            <input
                              type="checkbox"
                              checked={perm.write}
                              onChange={() => handlePermissionChange(perm.page_id, 'write')}
                              className="h-4 w-4 text-blue-950 border-gray-300 rounded focus:ring-blue-950"
                            />
                            <span className="ml-1 text-sm text-gray-700">Éditer</span>
                          </label>
                          <label className="w-1/6 flex items-center">
                            <input
                              type="checkbox"
                              checked={perm.hide}
                              onChange={() => handlePermissionChange(perm.page_id, 'hide')}
                              className="h-4 w-4 text-blue-950 border-gray-300 rounded focus:ring-blue-950"
                            />
                            <span className="ml-1 text-sm text-gray-700">Masquer</span>
                          </label>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 text-sm font-medium text-gray-700 transition-colors"
                >
                  Annuler
                </button>
                <button
                  onClick={handleSubmit}
                  className="px-4 py-2 bg-blue-950 text-white rounded-lg hover:bg-blue-800 text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={
                    !email ||
                    (useCustomPermissions && permissions.every((p) => !p.read && !p.write && !p.hide))
                  }
                >
                  {editingAccount ? 'Mettre à jour' : 'Créer'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Comptes;