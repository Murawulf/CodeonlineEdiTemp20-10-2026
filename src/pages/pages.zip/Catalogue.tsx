import React, { useState, useEffect, useRef } from 'react';
import Draggable from 'react-draggable';
import { Resizable } from 're-resizable';
import { useNotifications } from '../contexts/NotificationContext';
import * as XLSX from 'xlsx';

interface Product {
  id: number;
  brand: string;
  subBrand: string;
  description: string;
  gtin: string;
  libelle: string;
  short_libelle: string;
  countryOfOrigin: string;
  idEntreprise: number;
  images: string;
  nb_images: number;
  prix_min: number;
  prix_max: number;
  code_cader: string;
  codeClasse: number;
  codebrique: string;
  date_mis_a_jour_fp: string;
  tradeItemSynchronisationDates: string;
  date_create_fp: string;
  activ_prix: number;
  status: number;
  done_new: number;
  fabricant: string;
}

interface Option {
  id: string;
  name: string;
}

interface SortConfig {
  key: keyof Product | 'brick';
  direction: 'ascending' | 'descending';
}

interface Column {
  key: keyof Product | 'brick';
  label: string;
  render?: (product: Product) => React.ReactNode;
}

interface User {
  id_compte: number;
  email: string;
  name: string;
  certicode: string | null;
  role: string | null;
  is_suspended: number;
  created_at: string;
  id_entite: number | null;
  producer_name: string | null;
  profile_id: number | null;
  permissions: { page_id: number; read: number; write: number; hide: number }[];
}

const fabricantsMap: { [key: string]: string } = {
  '24': 'Les Beaux Arts Romains',
  '25': 'Mahdco Tunisie',
  '33': 'Société Monia Bouzid sarl',
  '34': 'Yutex Sarl',
  '35': 'Arex',
  '38': 'Celine Pharma',
  '70': 'SMVDA Domaine Néferis',
};

const marques: Option[] = [
  { id: 'Les Beaux Arts Romains', name: 'Les Beaux Arts Romains' },
  { id: 'SARALONA', name: 'SARALONA' },
  { id: 'Barka store', name: 'Barka store' },
  { id: 'Blue Island', name: 'Blue Island' },
  { id: 'SASIO FEMME', name: 'SASIO FEMME' },
  { id: 'HEALTH AND TECH', name: 'HEALTH AND TECH' },
  { id: 'SOPROTIC', name: 'SOPROTIC' },
  { id: 'TAW TAW', name: 'TAW TAW' },
  { id: 'Herbéos ', name: 'Herbéos ' },
  { id: 'MAGNIFIQUE BLANC', name: 'MAGNIFIQUE BLANC' },
  { id: 'MAGNIFIQUE ROUGE', name: 'MAGNIFIQUE ROUGE' },
  { id: 'MAGNIFIQUE ROSE ', name: 'MAGNIFIQUE ROSE ' },
  { id: 'VIEUX MAGNIFIQUE', name: 'VIEUX MAGNIFIQUE' },
  { id: 'SELAIN BLANC ', name: 'SELAIN BLANC ' },
  { id: 'SELIAN ROUGE ', name: 'SELIAN ROUGE ' },
  { id: 'SELIAN MYSTERE ROSE', name: 'SELIAN MYSTERE ROSE' },
  { id: 'SELIAN RESERVE ', name: 'SELIAN RESERVE ' },
  { id: 'VERDEJO ', name: 'VERDEJO ' },
  { id: 'DOMAINE NEFERIS', name: 'DOMAINE NEFERIS' },
];
const API_BASE =
  window.location.hostname.includes('localhost')
    ? 'https://edi-dev.codeonline-info.com'
    : '';

const secteurs: Option[] = [
  { id: '50202200', name: 'Nourriture/Boisson' },
  { id: '53131100', name: 'Beauté/Soin Personnel/Hygiène' },
  { id: '53141100', name: 'Soins Capillaires' },
  { id: '63010300', name: 'Chaussures' },
  { id: '67010300', name: 'Vêtements Habillement Textile' },
  { id: '67010800', name: 'Vêtements Médicaux' },
  { id: '67040100', name: 'Sous-vêtements' },
  { id: '99601000', name: "Métiers d'Art - Série Limitée" },
  { id: '99701000', name: 'Mobilier' },
];

const getStatusLabel = (status: number): string => {
  switch (status) {
    case 0:
      return 'Inactif';
    case 1:
      return 'Publié';
    case 2:
      return 'En attente';
    default:
      return 'Inconnu';
  }
};

const Catalogue: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState<number>(0);
  const [user, setUser] = useState<User | null>(null);
  const [viewType, setViewType] = useState<'normal' | 'producer' | 'cepex' | 'backoffice'>('normal');
  const [hasWritePermission, setHasWritePermission] = useState<boolean>(false);
  const [canEditStatus, setCanEditStatus] = useState<boolean>(false);
  const [selectedMarque, setSelectedMarque] = useState<string>('');
  const [selectedSecteur, setSelectedSecteur] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [itemsPerPage, setItemsPerPage] = useState<number>(25);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isMarqueOpen, setIsMarqueOpen] = useState<boolean>(false);
  const [isSecteurOpen, setIsSecteurOpen] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isBulkOpen, setIsBulkOpen] = useState<boolean>(false);
  const [bulkFile, setBulkFile] = useState<File | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newImages, setNewImages] = useState<File[]>([]);
  const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isActionOpen, setIsActionOpen] = useState<number | null>(null);
  const { addNotification } = useNotifications();
  const modalRef = useRef<HTMLDivElement>(null);
  const bulkModalRef = useRef<HTMLDivElement>(null);

  const generateExcelTemplate = () => {
    const headers = [
      'ID',
      'Marque*',
      'Sous-marque',
      'Description',
      'GTIN*',
      'Libellé*',
      'Libellé court',
      'Pays d\'origine',
      'ID Entreprise*',
      'Images',
      'Nombre d\'images',
      'Prix minimum',
      'Prix maximum',
      'Code Cader',
      'Code Classe',
      'Code Brique*',
      'Date mise à jour FP',
      'Dates de synchronisation',
      'Date de création FP',
      'Prix actif',
      'Statut',
      'Nouveau fait',
      'Fabricant',
    ];
    const ws = XLSX.utils.json_to_sheet([], { header: headers });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Produits');
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([wbout], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Modèle_Importation_Produits.xlsx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const parsedUser: User = JSON.parse(storedUser);
      setUser(parsedUser);
      if (parsedUser.email.includes('back_office')) {
        setViewType('backoffice');
      } else if (parsedUser.producer_name === 'Cepex') {
        setViewType('cepex');
      } else if (parsedUser.producer_name) {
        setViewType('producer');
      } else {
        setViewType('normal');
      }
      const cataloguePerm = parsedUser.permissions.find(p => p.page_id === 7);
      setHasWritePermission(cataloguePerm?.write === 1);
      setCanEditStatus(parsedUser.producer_name === 'Cepex' || parsedUser.producer_name === 'NETCONSULTING EUROPE LTD');
    } else {
      setViewType('normal');
      setHasWritePermission(false);
      setCanEditStatus(false);
    }
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
    try {
  const params = new URLSearchParams({
    ...(selectedMarque && { brand: selectedMarque }),
    ...(selectedSecteur && { codebrique: selectedSecteur }),
    ...(searchTerm && { search: searchTerm }),
    sortBy: sortConfig?.key || 'id',
    sortDir: sortConfig?.direction === 'ascending' ? 'ASC' : 'DESC',
    page: currentPage.toString(),
    limit: itemsPerPage.toString(),
  });

  const res = await fetch(`${API_BASE}/api/products?${params}`, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    console.error('❌ /api/products failed:', res.status, text);
    throw new Error(`Fetch failed: ${res.status}`);
  }

  const data = await res.json().catch((err) => {
    console.error('Invalid JSON from /api/products:', err);
    throw err;
  });

  setProducts(data.products || []);
  setTotalPages(data.totalPages || 1);
  setRetryCount(0);
} catch (err) {
  setError('Échec du chargement des produits. Veuillez réessayer plus tard.');
  console.error('Erreur de récupération des produits:', err);
}
 finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [selectedMarque, selectedSecteur, searchTerm, currentPage, itemsPerPage, sortConfig, retryCount]);

  const getColumns = (): Column[] => {
    const imageColumn: Column = {
      key: 'images',
      label: 'Image',
      render: (p) => (
        <img
          src={p.images ? p.images.split(';')[0] : '/placeholder-image.jpg'}
          alt={p.libelle}
          className="w-16 h-16 object-cover rounded-md cursor-pointer hover:opacity-80 transition-opacity"
          onError={(e) => (e.currentTarget.src = '/placeholder-image.jpg')}
          onClick={() => handleImageClick(p.images ? p.images.split(';')[0] : '/placeholder-image.jpg')}
        />
      ),
    };

    const brickColumn: Column = {
      key: 'brick',
      label: 'Catégorie',
      render: (p) => secteurs.find((s) => s.id === p.codebrique)?.name || p.codebrique,
    };

    const fabricantColumn: Column = {
      key: 'fabricant',
      label: 'Fabricant',
      render: (p) => fabricantsMap[p.fabricant] || p.fabricant,
    };

    const statusColumn: Column = {
      key: 'status',
      label: 'Statut',
      render: (p) => getStatusLabel(p.status),
    };

    switch (viewType) {
      case 'normal':
        return [
          imageColumn,
          { key: 'gtin', label: 'GTIN' },
          brickColumn,
          { key: 'brand', label: 'Marque' },
          { key: 'subBrand', label: 'Sous Marque' },
          { key: 'libelle', label: 'Libellé court' },
          { key: 'countryOfOrigin', label: 'Origine' },
          { key: 'code_cader', label: 'Type Prod' },
          { key: 'prix_min', label: 'Prix min' },
          { key: 'prix_max', label: 'Prix max' },
          statusColumn,
        ];
      case 'producer':
        return [
          imageColumn,
          { key: 'gtin', label: 'GTIN' },
          { key: 'libelle', label: 'Libellé court' },
          brickColumn,
          statusColumn,
        ];
      case 'backoffice':
      case 'cepex':
        return [
          imageColumn,
          fabricantColumn,
          { key: 'gtin', label: 'GTIN' },
          brickColumn,
          { key: 'brand', label: 'Marque' },
          { key: 'libelle', label: 'Libellé court' },
          statusColumn,
        ];
      default:
        return [];
    }
  };

  const columns = getColumns();

  const handleMarqueSelect = (marque: string) => {
    setSelectedMarque(marque);
    setIsMarqueOpen(false);
    setCurrentPage(1);
  };

  const handleSecteurSelect = (secteur: string) => {
    setSelectedSecteur(secteur);
    setIsSecteurOpen(false);
    setCurrentPage(1);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const handleAddClick = () => {
    setEditingProduct({
      id: 0,
      brand: '',
      subBrand: '',
      description: '',
      gtin: '',
      libelle: '',
      short_libelle: '',
      countryOfOrigin: '',
      idEntreprise: 0,
      images: '',
      nb_images: 0,
      prix_min: 0,
      prix_max: 0,
      code_cader: '',
      codeClasse: 0,
      codebrique: '',
      date_mis_a_jour_fp: '',
      tradeItemSynchronisationDates: '',
      date_create_fp: '',
      activ_prix: 0,
      status: 1,
      done_new: 0,
      fabricant: '',
    });
    setNewImages([]);
    setIsModalOpen(true);
  };

  const handleBulkClick = () => {
    setIsBulkOpen(true);
  };

 // 2) handleBulkSubmit - replace your current version
const handleBulkSubmit = async () => {
  if (!bulkFile) {
    addNotification('Veuillez sélectionner un fichier CSV ou Excel.', 'error');
    return;
  }
  const formData = new FormData();
  // your input name used by API is 'csv' (we used uploadGed.single('csv'))
  formData.append('csv', bulkFile);
  formData.append('compteId', user?.id_compte?.toString() || '');

  try {
    const res = await fetch('/api/products/bulk', {
      method: 'POST',
      body: formData,
      credentials: 'include',
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => null);
      console.error('Bulk import failed', res.status, txt);
      throw new Error('Échec de l\'importation');
    }
    const data = await res.json();
    addNotification(`Importation multiple de ${data.count || 0} produits réussie.`, 'success');
    setIsBulkOpen(false);
    setBulkFile(null);
    // trigger re-fetch of current page
    setRetryCount(prev => prev + 1);
  } catch (err) {
    console.error('Erreur d\'importation multiple:', err);
    addNotification('Échec de l\'importation des produits.', 'error');
  }
};

  const handleEditClick = (product: Product) => {
    setEditingProduct({ ...product });
    setNewImages([]);
    setIsModalOpen(true);
    setIsActionOpen(null);
  };

  const handleDeleteClick = async (productId: number) => {
    try {
      const res = await fetch(`/api/products/${productId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ compteId: user?.id_compte }),
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Échec de la suppression');
      setProducts(products.filter((p) => p.id !== productId));
      addNotification('Produit supprimé avec succès.', 'success');
    } catch (err) {
      console.error('Erreur de suppression:', err);
      addNotification('Échec de la suppression du produit.', 'error');
    } finally {
      setIsActionOpen(null);
    }
  };

  const handlePublier = async (productId: number) => {
    try {
      const res = await fetch(`/api/products/${productId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 1, compteId: user?.id_compte }),
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Échec de la publication');
      setProducts(products.map((p) => (p.id === productId ? { ...p, status: 1 } : p)));
      addNotification('Produit publié avec succès.', 'success');
    } catch (err) {
      console.error('Erreur de publication:', err);
      addNotification('Échec de la publication du produit.', 'error');
    } finally {
      setIsActionOpen(null);
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
    setNewImages([]);
  };

  const handleBulkModalClose = () => {
    setIsBulkOpen(false);
    setBulkFile(null);
  };

// 1) handleSaveChanges - replace your current version
const handleSaveChanges = async () => {
  if (!editingProduct) return;
  try {
    const formData = new FormData();
    // append all editingProduct fields
    Object.entries(editingProduct).forEach(([key, value]) => {
      // ensure numbers are stringified
      if (value === undefined || value === null) return;
      formData.append(key, String(value));
    });
    // compteId for notifications if needed
    formData.append('compteId', user?.id_compte?.toString() || '');

    // append new images if any
    newImages.forEach((file) => formData.append('images', file));

    const method = editingProduct.id === 0 ? 'POST' : 'PUT';
    const url = editingProduct.id === 0 ? '/api/products' : `/api/products/${editingProduct.id}`;

    const res = await fetch(url, {
      method,
      body: formData,
      credentials: 'include',
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => null);
      console.error('Save failed:', res.status, errText);
      throw new Error('Échec de l\'enregistrement');
    }

    const data = await res.json();

    // If create, API returns the created product -> insert on top
    if (editingProduct.id === 0 && data && data.id) {
      // data is the created product object (with images array)
      setProducts(prev => [data, ...prev]);
    } else if (editingProduct.id !== 0 && data && data.id) {
      // update existing in state
      setProducts(prev => prev.map(p => (p.id === data.id ? data : p)));
    } else {
      // fallback: trigger a refetch (safe)
      setRetryCount(prev => prev + 1);
    }

    addNotification(editingProduct.id === 0 ? 'Produit ajouté avec succès.' : 'Produit modifié avec succès.', 'success');
    handleModalClose();
    setRetryCount(0); // reset retry counter used for retrying on 503
  } catch (err) {
    console.error('Erreur d\'enregistrement:', err);
    addNotification('Échec de l\'enregistrement du produit.', 'error');
  }
};




  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    if (editingProduct) {
      const { name, value } = e.target;
      setEditingProduct({
        ...editingProduct,
        [name]: ['prix_min', 'prix_max', 'nb_images', 'codeClasse', 'activ_prix', 'status', 'done_new', 'idEntreprise'].includes(name)
          ? Number(value)
          : value,
      });
    }
  };

  const handleSort = (key: keyof Product | 'brick') => {
    const direction = sortConfig?.key === key && sortConfig.direction === 'ascending' ? 'descending' : 'ascending';
    setSortConfig({ key, direction });
    setCurrentPage(1);
  };

  const handleImageClick = (image: string) => {
    setSelectedImage(image);
  };

  const handleCloseImage = () => {
    setSelectedImage(null);
  };

  const toggleActionDropdown = (productId: number) => {
    setIsActionOpen(isActionOpen === productId ? null : productId);
  };

  const renderSortArrow = (key: keyof Product | 'brick') => {
    const isActive = sortConfig?.key === key;
    const isAscending = sortConfig?.direction === 'ascending';
    return (
      <span className={`ml-1 text-xs ${isActive ? 'text-white font-bold' : 'text-gray-300'}`}>
        {isActive ? (isAscending ? '↓' : '↑') : '↓'}
      </span>
    );
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const showActions = hasWritePermission;
  const showAddButton = hasWritePermission;
  const showFilters = viewType === 'backoffice' || viewType === 'cepex';

  if (loading) {
    return <div className="container mx-auto p-6 text-center">Chargement des produits...</div>;
  }

  if (error) {
    return (
      <div className="container mx-auto p-6 text-center text-red-600">
        {error}
        <button
          className="ml-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          onClick={() => setRetryCount(retryCount + 1)}
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <nav className="flex items-center space-x-2 text-sm">
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px', fontWeight: '500' }}>
          Produits
        </span>
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px' }}>/</span>
        <span style={{ color: '#3b82f6', position: 'relative', top: '-14px', fontWeight: '500' }}>
          Catalogue FP
        </span>
      </nav>
      <div className="container mx-auto p-6">
        {showAddButton && (
          <div className="flex justify-end mb-4 space-x-4">
            <button
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg"
              onClick={handleAddClick}
            >
              Ajouter un Produit
            </button>
            <button
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors shadow-md hover:shadow-lg"
              onClick={handleBulkClick}
            >
              Importer Multiple
            </button>
          </div>
        )}

        {showFilters && (
          <div className="flex flex-col md:flex-row gap-4 mb-6 bg-white p-4 rounded-lg shadow-md">
            <div className="relative flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Marque</label>
              <div
                className="p-3 border rounded-md cursor-pointer bg-white text-sm w-full hover:bg-gray-50 transition-colors"
                onClick={() => setIsMarqueOpen(!isMarqueOpen)}
              >
                {selectedMarque || 'Choisir une marque'}
              </div>
              {isMarqueOpen && (
                <div className="absolute z-10 mt-2 w-full bg-white border rounded-md shadow-lg max-h-80 overflow-auto">
                  <div className="p-3 hover:bg-blue-100 cursor-pointer text-sm" onClick={() => handleMarqueSelect('')}>
                    Toutes les marques
                  </div>
                  {marques.map((marque) => (
                    <div
                      key={marque.id}
                      className="p-3 hover:bg-blue-100 cursor-pointer text-sm"
                      onClick={() => handleMarqueSelect(marque.name)}
                    >
                      {marque.name}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="relative flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Secteur</label>
              <div
                className="p-3 border rounded-md cursor-pointer bg-white text-sm w-full hover:bg-gray-50 transition-colors"
                onClick={() => setIsSecteurOpen(!isSecteurOpen)}
              >
                {selectedSecteur ? secteurs.find((s) => s.id === selectedSecteur)?.name || 'Sélectionner un secteur' : 'Choisir un secteur'}
              </div>
              {isSecteurOpen && (
                <div className="absolute z-10 mt-2 w-full bg-white border rounded-md shadow-lg max-h-80 overflow-auto">
                  <div className="p-3 hover:bg-blue-100 cursor-pointer text-sm" onClick={() => handleSecteurSelect('')}>
                    Tous les secteurs
                  </div>
                  {secteurs.map((secteur) => (
                    <div
                      key={secteur.id}
                      className="p-3 hover:bg-blue-100 cursor-pointer text-sm"
                      onClick={() => handleSecteurSelect(secteur.id)}
                    >
                      {secteur.name}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Recherche</label>
              <input
                type="text"
                className="p-3 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow hover:shadow-sm"
                placeholder="Rechercher..."
                value={searchTerm}
                onChange={handleSearch}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Prod / Page</label>
              <select
                className="p-3 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-shadow hover:shadow-sm"
                value={itemsPerPage}
                onChange={(e) => {
                  setItemsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>
        )}

        <div className="overflow-x-auto rounded-lg shadow-lg">
          <table className="min-w-full border border-gray-200">
            <thead className="bg-blue-950 text-white">
              <tr className="text-left text-sm font-semibold">
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className="p-4 cursor-pointer hover:bg-blue-800 transition-colors"
                    onClick={() => handleSort(col.key)}
                  >
                    <span className="flex items-center">
                      {col.label}
                      {renderSortArrow(col.key)}
                    </span>
                  </th>
                ))}
                {showActions && <th className="p-4 hover:bg-blue-800 transition-colors">Action</th>}
              </tr>
            </thead>
            <tbody>
              {products.length > 0 ? (
                products.map((product) => (
                  <tr key={product.id} className="border-t hover:bg-gray-50 transition-colors">
                    {columns.map((col) => (
                      <td key={col.key} className="p-4 text-sm">
                        {col.render ? col.render(product) : (product[col.key as keyof Product] ?? 'N/A')}
                      </td>
                    ))}
                    {showActions && (
                      <td className="p-4 text-sm relative">
                        <button
                          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow hover:shadow-md"
                          onClick={() => toggleActionDropdown(product.id)}
                        >
                          Action
                        </button>
                        {isActionOpen === product.id && (
                          <div className="absolute z-10 mt-2 w-48 bg-white border rounded-md shadow-lg right-0">
                            <div
                              className="p-3 hover:bg-blue-100 cursor-pointer text-sm"
                              onClick={() => handleEditClick(product)}
                            >
                              Modifier
                            </div>
                            {product.status === 2 && canEditStatus && (
                              <div
                                className="p-3 hover:bg-blue-100 cursor-pointer text-sm"
                                onClick={() => handlePublier(product.id)}
                              >
                                <svg className="w-6 h-6 inline-block mr-2 text-blue-950" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M8 5v10l7-5z" />
                                </svg>
                                Publier
                              </div>
                            )}
                            <div
                              className="p-3 hover:bg-blue-100 cursor-pointer text-sm"
                              onClick={() => handleDeleteClick(product.id)}
                            >
                              Supprimer
                            </div>
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={columns.length + (showActions ? 1 : 0)} className="p-4 text-center text-sm text-gray-500">
                    Aucun produit trouvé
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {selectedImage && (
          <div
            className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 backdrop-blur-lg"
            onClick={handleCloseImage}
          >
            <div className="relative max-w-4xl w-full p-4" onClick={(e) => e.stopPropagation()}>
              <img
                src={selectedImage}
                alt="Produit en plein écran"
                className="w-full h-auto max-h-[80vh] object-contain rounded-lg shadow-2xl"
                onError={(e) => (e.currentTarget.src = '/placeholder-image.jpg')}
              />
              <button
                className="absolute top-4 right-4 bg-gray-800 text-white rounded-full p-2 hover:bg-gray-700 transition-colors"
                onClick={handleCloseImage}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {isModalOpen && editingProduct && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            onClick={handleModalClose}
          >
            <Draggable handle=".modal-handle" nodeRef={modalRef}>
              <Resizable
                defaultSize={{ width: 500, height: 600 }}
                minWidth={300}
                minHeight={400}
                maxWidth={800}
                maxHeight={800}
                enable={{
                  top: false,
                  right: true,
                  bottom: true,
                  left: true,
                  topRight: false,
                  bottomRight: true,
                  bottomLeft: true,
                  topLeft: false,
                }}
                onResizeStart={(e) => e.stopPropagation()}
                onResize={(e) => e.stopPropagation()}
              >
                <div
                  ref={modalRef}
                  className="bg-white p-6 rounded-lg shadow-xl overflow-y-auto max-h-[80vh] select-none cursor-move"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="modal-handle bg-gray-300 p-2 rounded-t-md cursor-move text-center text-sm font-semibold">
                    {editingProduct.id === 0 ? 'Ajouter un Produit' : 'Modifier le produit'}
                  </div>
                  <div className="space-y-4 mt-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Marque</label>
                      <input
                        type="text"
                        name="brand"
                        value={editingProduct.brand}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Sous Marque</label>
                      <input
                        type="text"
                        name="subBrand"
                        value={editingProduct.subBrand}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Description</label>
                      <input
                        type="text"
                        name="description"
                        value={editingProduct.description}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">GTIN</label>
                      <input
                        type="text"
                        name="gtin"
                        value={editingProduct.gtin}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Libellé</label>
                      <input
                        type="text"
                        name="libelle"
                        value={editingProduct.libelle}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Libellé Court</label>
                      <input
                        type="text"
                        name="short_libelle"
                        value={editingProduct.short_libelle}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Origine</label>
                      <input
                        type="text"
                        name="countryOfOrigin"
                        value={editingProduct.countryOfOrigin}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">ID Entreprise</label>
                      <input
                        type="number"
                        name="idEntreprise"
                        value={editingProduct.idEntreprise}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Images actuelles (; séparées)</label>
                      <div className="flex flex-wrap gap-2">
                        {editingProduct.images.split(';').filter(Boolean).map((img, idx) => (
                          <img key={idx} src={img} alt={`Image ${idx}`} className="w-20 h-20 object-cover rounded" onError={(e) => (e.currentTarget.src = '/placeholder-image.jpg')} />
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Télécharger nouvelles images</label>
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={(e) => setNewImages(Array.from(e.target.files || []))}
                        className="p-2 border rounded-md w-full text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Prix Min</label>
                      <input
                        type="number"
                        name="prix_min"
                        value={editingProduct.prix_min}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Prix Max</label>
                      <input
                        type="number"
                        name="prix_max"
                        value={editingProduct.prix_max}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Code Cader</label>
                      <input
                        type="text"
                        name="code_cader"
                        value={editingProduct.code_cader}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Code Classe</label>
                      <input
                        type="number"
                        name="codeClasse"
                        value={editingProduct.codeClasse}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Code Brique (Catégorie)</label>
                      <select
                        name="codebrique"
                        value={editingProduct.codebrique}
                        onChange={handleInputChange}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {secteurs.map((secteur) => (
                          <option key={secteur.id} value={secteur.id}>
                            {secteur.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Statut</label>
                      <select
                        name="status"
                        value={editingProduct.status}
                        onChange={handleInputChange}
                        disabled={!canEditStatus}
                        className="p-2 border rounded-md w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value={0}>Inactif</option>
                        <option value={1}>Publié</option>
                        <option value={2}>En attente</option>
                      </select>
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end gap-4">
                    <button
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors"
                      onClick={handleModalClose}
                    >
                      Annuler
                    </button>
                    <button
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      onClick={handleSaveChanges}
                    >
                      Enregistrer
                    </button>
                  </div>
                </div>
              </Resizable>
            </Draggable>
          </div>
        )}

        {isBulkOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            onClick={handleBulkModalClose}
          >
            <Draggable handle=".bulk-modal-handle" nodeRef={bulkModalRef}>
              <Resizable
                defaultSize={{ width: 500, height: 400 }}
                minWidth={300}
                minHeight={300}
                maxWidth={800}
                maxHeight={600}
                enable={{
                  top: false,
                  right: true,
                  bottom: true,
                  left: true,
                  topRight: false,
                  bottomRight: true,
                  bottomLeft: true,
                  topLeft: false,
                }}
                onResizeStart={(e) => e.stopPropagation()}
                onResize={(e) => e.stopPropagation()}
              >
                <div
                  ref={bulkModalRef}
                  className="bg-white p-6 rounded-lg shadow-xl overflow-y-auto max-h-[80vh] select-none cursor-move"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="bulk-modal-handle bg-gray-300 p-2 rounded-t-md cursor-move text-center text-sm font-semibold">
                    Importer Multiple des Produits
                  </div>
                  <div className="space-y-4 mt-4">
                    <div className="bg-gray-100 p-4 rounded-md">
                      <h3 className="text-md font-medium text-gray-800 mb-2">Modèle Excel</h3>
                      <p className="text-sm text-gray-600 mb-2">
                        Téléchargez le modèle Excel ci-dessous pour vous assurer que votre fichier respecte la structure requise.
                      </p>
                      <button
                        className="inline-block px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                        onClick={generateExcelTemplate}
                      >
                        Télécharger le modèle Excel
                      </button>
                      <p className="text-sm text-gray-600 mt-2">
                        Remplissez le fichier avec les données des produits. Les colonnes obligatoires sont marquées par un astérisque (*).
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Télécharger fichier CSV ou Excel</label>
                      <input
                        type="file"
                        accept=".csv,.xlsx"
                        onChange={(e) => setBulkFile(e.target.files?.[0] || null)}
                        className="p-2 border rounded-md w-full text-sm mt-1"
                      />
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end gap-4">
                    <button
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors"
                      onClick={handleBulkModalClose}
                    >
                      Annuler
                    </button>
                    <button
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      onClick={handleBulkSubmit}
                    >
                      Importer
                    </button>
                  </div>
                </div>
              </Resizable>
            </Draggable>
          </div>
        )}

        {totalPages > 1 && (
          <div className="flex justify-center items-center mt-6 gap-4">
            <button
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              Précédent
            </button>
            <span className="text-sm text-gray-700">
              Page {currentPage} de {totalPages}
            </span>
            <button
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 transition-colors"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              Suivant
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Catalogue;