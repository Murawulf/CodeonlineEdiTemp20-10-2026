  import React, { useState, useEffect, useRef, useCallback } from 'react';
  import axios from 'axios';
  import ReactQuill from 'react-quill';
  import 'react-quill/dist/quill.snow.css';
  import Draggable from 'react-draggable';
  import { XMarkIcon } from '@heroicons/react/24/outline';
  import { NotificationProvider, useNotifications } from '../contexts/NotificationContext';
  import { debounce } from 'lodash';

  interface Company {
    id_entite: number;
    raison_socialle: string;
    gln: string | null;
    date_create: string | null;
    pays: string | null;
    site: string | null;
    personne_contact: string | null;
    service: string | null;
    email: string | null;
    tel_mobile: string | null;
    telephone: string | null;
    fax: string | null;
    adresse: string | null;
    region: string | null;
    city: string | null;
    localite: string | null;
    postalCode: string | null;
    type_prod: number;
    statut: number;
    date_abonnement: string | null;
    date_echeance: string | null;
    nb_fp: number;
    inscription: number;
    status_ent: string;
    delegation: string | null;
    segments: string[];
    titre_fr: string | null;
    titre_ar: string | null;
    titre_en: string | null;
    logo: string | null;
  }

  interface Segment {
    code: string;
    libelle: string;
  }

  interface Region {
    region: string;
  }

  interface Delegation {
    delegation: string;
  }

  interface SortConfig {
    key: keyof Company;
    direction: 'ascending' | 'descending';
  }

  interface Permission {
    page_id: number;
    read: number;
    write: number;
    hide: number;
    page_name: string;
  }

  interface User {
    id_compte: number;
    email: string;
    name: string;
    prenom: string;
    certicode: string | null;
    role: string | null;
    is_suspended: number;
    created_at: string;
    id_entite: number;
    producer_name: string;
    profile_id: number;
    permissions: Permission[];
  }

  const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://edi-dev.codeonline-info.com';

  const typeOptions = [
    { value: '1', label: 'Entreprise privée produits & services' },
    { value: '2', label: 'Entreprise privée ingénierie & services' },
    { value: '3', label: 'Entreprise privée transport logistique & stockage' },
    { value: '4', label: 'Entreprise publique transport logistique & stockage' },
    { value: '5', label: 'Entreprise publique produits & services' },
    { value: '6', label: 'Entreprise publique ingénierie & services' },
    { value: '7', label: 'Autre institution publique d’appui à l’exportation' },
    { value: '8', label: 'Banque' },
    { value: '9', label: 'Douane' },
    { value: '10', label: 'Assurance' },
  ];

  const statutOptions = [
    { value: '0', label: 'Inactif' },
    { value: '1', label: 'Actif' },
  ];

  const inscriptionOptions = [
    { value: '0', label: 'Non' },
    { value: '1', label: 'Oui' },
  ];

  const quillModules = {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ['bold', 'italic', 'underline'],
      [{ color: [] }],
      [{ align: [] }],
      ['clean'],
    ],
  };

  const Entite: React.FC = () => {
    const [companies, setCompanies] = useState<Company[]>([]);
    const [segments, setSegments] = useState<Segment[]>([]);
    const [regions, setRegions] = useState<Region[]>([]);
    const [delegations, setDelegations] = useState<Delegation[]>([]);
    const [searchRegion, setSearchRegion] = useState<string>('');
    const [searchSegment, setSearchSegment] = useState<string>('');
    const [searchDelegation, setSearchDelegation] = useState<string>('');
    const [searchType, setSearchType] = useState<string>('');
    const [searchText, setSearchText] = useState<string>('');
    const [expandedRow, setExpandedRow] = useState<number | null>(null);
    const [editingCompany, setEditingCompany] = useState<Company | null>(null);
    const [editingField, setEditingField] = useState<{ id: number; field: string; value: string } | null>(null);
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const [isLogoModalOpen, setIsLogoModalOpen] = useState<boolean>(false);
    const [selectedLogo, setSelectedLogo] = useState<string | null>(null);
    const [modalSegments, setModalSegments] = useState<string[]>([]);
    const [isModalRegionOpen, setIsModalRegionOpen] = useState<boolean>(false);
    const [isModalDelegationOpen, setIsModalDelegationOpen] = useState<boolean>(false);
    const [isSelectLangModalOpen, setIsSelectLangModalOpen] = useState<boolean>(false);
    const [isEditTitleModalOpen, setIsEditTitleModalOpen] = useState<boolean>(false);
    const [isTextModalOpen, setIsTextModalOpen] = useState<boolean>(false);
    const [selectedText, setSelectedText] = useState<string>('');
    const [selectedTextTitle, setSelectedTextTitle] = useState<string>('');
    const [selectedLang, setSelectedLang] = useState<'fr' | 'ar' | 'en' | null>(null);
    const [editTitle, setEditTitle] = useState<string>('');
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(25);
    const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);
    const [isRegionOpen, setIsRegionOpen] = useState<boolean>(false);
    const [isSegmentOpen, setIsSegmentOpen] = useState<boolean>(false);
    const [isDelegationOpen, setIsDelegationOpen] = useState<boolean>(false);
    const [isTypeOpen, setIsTypeOpen] = useState<boolean>(false);
    const [isActionOpen, setIsActionOpen] = useState<number | null>(null);
    const [isMainActionOpen, setIsMainActionOpen] = useState<boolean>(false);
    const [profileExists, setProfileExists] = useState<{ [key: number]: boolean }>({});
    const [canWrite, setCanWrite] = useState<boolean>(false);
    const [dropdownPosition, setDropdownPosition] = useState<{ top: number; left: number } | null>(null);
    const [rawLogo, setRawLogo] = useState<string | null>(null);
    const [previewLogo, setPreviewLogo] = useState<string | null>(null);
    const [logoFile, setLogoFile] = useState<File | null>(null);
    const [compteId, setCompteId] = useState<number | null>(null);
    const [logoErrorCount, setLogoErrorCount] = useState<{ [key: number]: number }>({});
    const [user, setUser] = useState<User | null>(null);
    const [showAll, setShowAll] = useState<boolean>(false);

    const { addNotification } = useNotifications();

    const regionRef = useRef<HTMLDivElement>(null);
    const segmentRef = useRef<HTMLDivElement>(null);
    const delegationRef = useRef<HTMLDivElement>(null);
    const typeRef = useRef<HTMLDivElement>(null);
    const modalRef = useRef<HTMLDivElement>(null);
    const modalRegionRef = useRef<HTMLDivElement>(null);
    const modalDelegationRef = useRef<HTMLDivElement>(null);
    const mainActionRef = useRef<HTMLDivElement>(null);
    const selectLangModalRef = useRef<HTMLDivElement>(null);
    const editTitleModalRef = useRef<HTMLDivElement>(null);
    const textModalRef = useRef<HTMLDivElement>(null);
    const logoModalRef = useRef<HTMLDivElement>(null);
    const tableRef = useRef<HTMLDivElement>(null);

    const handleTableScroll = useCallback(() => {
      setIsActionOpen(null);
      setDropdownPosition(null);
    }, []);

    const debouncedAddNotification = useCallback(
      debounce((message: string, type: string) => {
        addNotification(message, type);
      }, 1000),
      [addNotification]
    );

const getLogoUrl = (logo: string | null): string => {
  if (!logo) return '/fallback-logo.png';

  // Base64 or external URLs
  if (logo.startsWith('data:') || logo.startsWith('http')) return logo;

  // Normalize path
  const cleanPath = logo.startsWith('/') ? logo : '/' + logo;

  // Full URL with timestamp cache-busting
  return `${API_BASE_URL}${cleanPath}?t=${Date.now()}`;
};



    const handleLogoError = (e: React.SyntheticEvent<HTMLImageElement>, id: number) => {
      e.currentTarget.src = '/fallback-logo.png';
      setLogoErrorCount((prev) => {
        const newCount = (prev[id] || 0) + 1;
        if (newCount === 1) {
          debouncedAddNotification(`Échec du chargement du logo pour l'ID ${id}`, 'error');
          setCompanies((prevCompanies) =>
            prevCompanies.map((c) => {
              if (c.id_entite === id) {
                return { ...c, logo: null };
              }
              return c;
            })
          );
        }
        return { ...prev, [id]: newCount };
      });
    };

    const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 2097152) { // 2MB
        addNotification('Fichier trop volumineux (max 2 Mo)', 'error');
        return;
      }
      if (!file.type.startsWith('image/')) {
        addNotification('Type de fichier non supporté', 'error');
        return;
      }
      setLogoFile(file);
      setPreviewLogo(URL.createObjectURL(file));
    };

    const handleLogoDelete = () => {
      setLogoFile(null);
      setPreviewLogo(null);
    };

    useEffect(() => {
      const userData = localStorage.getItem('user');
      if (userData) {
        try {
          const parsedUser: User = JSON.parse(userData);
          setUser(parsedUser);
          setCompteId(parsedUser.id_compte);
          const entitePermission = parsedUser.permissions.find(p => p.page_id === 2);
          setCanWrite(entitePermission ? entitePermission.write === 1 : false);
          setShowAll(parsedUser.producer_name === 'NETCONSULTING EUROPE LTD');
        } catch (error) {
          console.error('Error parsing user data from localStorage:', error);
          setCanWrite(false);
          setCompteId(null);
          setShowAll(false);
          debouncedAddNotification('Erreur de chargement des données utilisateur', 'error');
        }
      } else {
        setCanWrite(false);
        setCompteId(null);
        setShowAll(false);
      }
    }, [debouncedAddNotification]);

    useEffect(() => {
      fetchCompanies();
      fetchSegments();
      fetchRegions();
      fetchDelegations();
    }, [searchRegion, searchSegment, searchDelegation, searchType]);
      const checkProfilesExist = useCallback(async (ids: number[]) => {
      if (!ids || ids.length === 0) return;
      try {
        const promises = ids.map(id =>
          axios.get(`${API_BASE_URL}/api/check-supervisor-profile/${id}`, { withCredentials: true })
            .catch(err => ({ error: err, id })
          )
        );
        const responses = await Promise.all(promises);
        const results: { [key: number]: boolean } = {};
        responses.forEach(response => {
          if ('error' in response) {
            console.error('Error checking supervisor profile:', {
              id_entite: response.id,
              message: response.error.message,
              response: response.error.response?.data,
            });
            results[response.id] = false;
          } else {
            results[response.data.id] = response.data.exists;
          }
        });
        setProfileExists(prev => ({ ...prev, ...results }));
      } catch (error: any) {
        console.error('Error checking supervisor profiles:', {
          ids,
          message: error.message,
          response: error.response?.data,
        });
        const fallback = ids.reduce((acc, id) => ({ ...acc, [id]: false }), {});
        setProfileExists(prev => ({ ...prev, ...fallback }));
        debouncedAddNotification('Échec de la vérification des profils superviseurs', 'error');
      }
    }, [debouncedAddNotification]);

    const baseCompanies = showAll || !user ? companies : companies.filter(c => c.id_entite === user.id_entite);

    const filteredCompanies = baseCompanies.filter(company =>
      company.raison_socialle.toLowerCase().includes(searchText.toLowerCase()) ||
      (company.personne_contact || '').toLowerCase().includes(searchText.toLowerCase()) ||
      (company.email || '').toLowerCase().includes(searchText.toLowerCase())
    );

    const paginatedCompanies = filteredCompanies.slice(
      (currentPage - 1) * itemsPerPage,
      currentPage * itemsPerPage
    );

    const visibleTotal = Math.min(baseCompanies.length, 9999);

    useEffect(() => {
      if (paginatedCompanies.length > 0 && canWrite) {
        const ids = paginatedCompanies.map(c => c.id_entite).filter(id => !(id in profileExists));
        if (ids.length > 0) {
          checkProfilesExist(ids);
        }
      }
    }, [paginatedCompanies, profileExists, checkProfilesExist, canWrite]);

    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (
          regionRef.current && !regionRef.current.contains(event.target as Node) &&
          segmentRef.current && !segmentRef.current.contains(event.target as Node) &&
          delegationRef.current && !delegationRef.current.contains(event.target as Node) &&
          typeRef.current && !typeRef.current.contains(event.target as Node) &&
          modalRef.current && !modalRef.current.contains(event.target as Node) &&
          modalRegionRef.current && !modalRegionRef.current.contains(event.target as Node) &&
          modalDelegationRef.current && !modalDelegationRef.current.contains(event.target as Node) &&
          mainActionRef.current && !mainActionRef.current.contains(event.target as Node) &&
          selectLangModalRef.current && !selectLangModalRef.current.contains(event.target as Node) &&
          editTitleModalRef.current && !editTitleModalRef.current.contains(event.target as Node) &&
          textModalRef.current && !textModalRef.current.contains(event.target as Node) &&
          logoModalRef.current && !logoModalRef.current.contains(event.target as Node)
        ) {
          setIsRegionOpen(false);
          setIsSegmentOpen(false);
          setIsDelegationOpen(false);
          setIsTypeOpen(false);
          setIsModalRegionOpen(false);
          setIsModalDelegationOpen(false);
          setIsMainActionOpen(false);
          setIsModalOpen(false);
          setIsSelectLangModalOpen(false);
          setIsEditTitleModalOpen(false);
          setIsTextModalOpen(false);
          setIsLogoModalOpen(false);
          setIsActionOpen(null);
          setDropdownPosition(null);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
      const tableElement = tableRef.current;
      if (tableElement) {
        tableElement.addEventListener('scroll', handleTableScroll);
        return () => tableElement.removeEventListener('scroll', handleTableScroll);
      }
    }, [handleTableScroll]);

    useEffect(() => {
      if (editingCompany?.region && editingCompany.region !== searchRegion) {
        fetchDelegations(editingCompany.region as string);
        setEditingCompany(prev => prev ? { ...prev, city: null, delegation: null } : null);
      }
    }, [editingCompany?.region, searchRegion]);

    const fetchCompanies = async (retries = 3) => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/companies`, {
          params: { region: searchRegion, segment: searchSegment, delegation: searchDelegation, type: searchType },
          withCredentials: true,
        });
        setCompanies(response.data);
      } catch (error: any) {
        if (error.response?.status === 500 && retries > 0) {
          console.warn(`Retrying fetchCompanies (attempts left: ${retries})`);
          setTimeout(() => fetchCompanies(retries - 1), 1000);
          return;
        }
        debouncedAddNotification('Échec de la récupération des entreprises', 'error');
        console.error('Fetch companies error:', { message: error.message, response: error.response?.data });
      }
    };

    const fetchSegments = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/segments`, { withCredentials: true });
        setSegments(response.data);
      } catch (error: any) {
        debouncedAddNotification('Échec de la récupération des segments', 'error');
        console.error('Fetch segments error:', { message: error.message, response: error.response?.data });
      }
    };

    const fetchRegions = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/regions`, { withCredentials: true });
        setRegions(response.data);
      } catch (error: any) {
        debouncedAddNotification('Échec de la récupération des régions', 'error');
        console.error('Fetch regions error:', { message: error.message, response: error.response?.data });
      }
    };

    const fetchDelegations = async (region: string = searchRegion) => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/delegations`, {
          params: { region },
          withCredentials: true,
        });
        setDelegations(response.data);
      } catch (error: any) {
        debouncedAddNotification('Échec de la récupération des délégations', 'error');
        console.error('Fetch delegations error:', { message: error.message, response: error.response?.data });
      }
    };

    const handleCreateSupervisorProfile = async (company: Company) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      try {
        await axios.post(
          `${API_BASE_URL}/api/create-supervisor-profile`,
          { id_entite: company.id_entite, raison_socialle: company.raison_socialle },
          { withCredentials: true }
        );
        setProfileExists(prev => ({ ...prev, [company.id_entite]: true }));
        setIsActionOpen(null);
        debouncedAddNotification('Profil superviseur créé avec succès', 'success');
      } catch (error: any) {
        debouncedAddNotification(`Échec de la création du profil superviseur: ${error.response?.data?.error || error.message}`, 'error');
        console.error('Create supervisor profile error:', {
          id_entite: company.id_entite,
          message: error.message,
          response: error.response?.data,
        });
      }
    };

    const handleRegionSelect = (region: string) => {
      setSearchRegion(region);
      setSearchDelegation('');
      fetchDelegations(region);
      setIsRegionOpen(false);
      setIsSegmentOpen(false);
      setIsDelegationOpen(false);
      setIsTypeOpen(false);
      setCurrentPage(1);
    };

    const handleSegmentSelect = (segment: string) => {
      setSearchSegment(segment);
      setIsSegmentOpen(false);
      setIsRegionOpen(false);
      setIsDelegationOpen(false);
      setIsTypeOpen(false);
      setCurrentPage(1);
    };

    const handleDelegationSelect = (delegation: string) => {
      setSearchDelegation(delegation);
      setIsDelegationOpen(false);
      setIsRegionOpen(false);
      setIsSegmentOpen(false);
      setIsTypeOpen(false);
      setCurrentPage(1);
    };

    const handleTypeSelect = (type: string) => {
      setSearchType(type);
      setIsTypeOpen(false);
      setIsRegionOpen(false);
      setIsSegmentOpen(false);
      setIsDelegationOpen(false);
      setCurrentPage(1);
    };

    const handleModalRegionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const newRegion = e.target.value || null;
      setEditingCompany(prev => prev ? { ...prev, region: newRegion, city: null, delegation: null } : null);
      if (newRegion) {
        fetchDelegations(newRegion);
      } else {
        setDelegations([]);
      }
    };

    const handleModalCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const newCity = e.target.value || null;
      setEditingCompany(prev => prev ? { ...prev, city: newCity, delegation: newCity } : null);
    };

    const toggleRow = (id: number) => {
      setExpandedRow(expandedRow === id ? null : id);
    };

    const handleAddCompany = async () => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      try {
        const response = await axios.get(`${API_BASE_URL}/api/companies/max-id`, { withCredentials: true });
        const newId = (response.data.max_id || 0) + 1;
        setEditingCompany({
          id_entite: newId,
          raison_socialle: '',
          gln: null,
          date_create: new Date().toISOString().split('T')[0],
          pays: null,
          site: null,
          personne_contact: null,
          service: null,
          email: null,
          tel_mobile: null,
          telephone: null,
          fax: null,
          adresse: null,
          region: null,
          city: null,
          localite: null,
          postalCode: null,
          type_prod: 0,
          statut: 1,
          date_abonnement: null,
          date_echeance: null,
          nb_fp: 0,
          inscription: 0,
          status_ent: 'A',
          delegation: null,
          segments: [],
          titre_fr: null,
          titre_ar: null,
          titre_en: null,
          logo: null,
        });
        setModalSegments([]);
        setLogoFile(null);
        setPreviewLogo(null);
        setIsModalOpen(true);
        setIsActionOpen(null);
        setIsMainActionOpen(false);
      } catch (error: any) {
        debouncedAddNotification('Échec de la récupération de l\'ID max', 'error');
        console.error('Fetch max-id error:', { message: error.message, response: error.response?.data });
      }
    };

    const handleEditCompany = (company: Company) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      setEditingCompany(company);
      setModalSegments(company.segments?.slice(0, 4) || []);
      setLogoFile(null);
      setPreviewLogo(company.logo ? getLogoUrl(company.logo) : null);
      fetchDelegations(company.region || '');
      setIsModalOpen(true);
      setIsActionOpen(null);
    };

    const openSelectLangModal = (company: Company) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      setEditingCompany(company);
      setIsSelectLangModalOpen(true);
      setIsActionOpen(null);
    };

    const openEditTitleModal = (lang: 'fr' | 'ar' | 'en') => {
      if (!editingCompany) return;
      setSelectedLang(lang);
      setEditTitle(editingCompany[`titre_${lang}`] || '');
      setIsSelectLangModalOpen(false);
      setIsEditTitleModalOpen(true);
    };

    const openTextModal = (text: string, title: string) => {
      setSelectedText(text);
      setSelectedTextTitle(title);
      setIsTextModalOpen(true);
    };

    const openLogoModal = (logo: string) => {
      setSelectedLogo(logo);
      setIsLogoModalOpen(true);
    };

    const handleEditField = async (id: number, field: string, value: string | null) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      try {
        await axios.put(
          `${API_BASE_URL}/api/companies/update-field`,
          { id_entite: id, field, value: value || null },
          { withCredentials: true }
        );
        setCompanies(companies.map(c => (c.id_entite === id ? { ...c, [field]: value } : c)));
        setEditingField(null);
        const fieldLabels: { [key: string]: string } = {
          raison_socialle: 'Raison sociale',
          personne_contact: 'Personne de contact',
          email: 'Email',
          tel_mobile: 'Téléphone mobile',
          telephone: 'Téléphone',
          fax: 'Fax',
          adresse: 'Adresse',
          region: 'Région',
          city: 'Ville',
          localite: 'Localité',
          postalCode: 'Code postal',
          gln: 'GLN',
          site: 'Site',
          date_create: 'Date de création',
          service: 'Service',
          delegation: 'Délégation',
          logo: 'Logo',
        };
        debouncedAddNotification(`${fieldLabels[field] || field} mise à jour avec succès`, 'success');
      } catch (error: any) {
        debouncedAddNotification(`Échec de la mise à jour de ${field}: ${error.response?.data?.error || error.message}`, 'error');
        console.error('Edit field error:', {
          id_entite: id,
          field,
          message: error.message,
          response: error.response?.data,
        });
      }
    };

    const handleTitleUpdate = async () => {
      if (!editingCompany || !selectedLang) return;
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      try {
        await axios.put(
          `${API_BASE_URL}/api/companies/update-field`,
          {
            id_entite: editingCompany.id_entite,
            field: `titre_${selectedLang}`,
            value: editTitle || null,
          },
          { withCredentials: true }
        );
        setCompanies(
          companies.map(c =>
            c.id_entite === editingCompany.id_entite
              ? { ...c, [`titre_${selectedLang}`]: editTitle }
              : c
          )
        );
        debouncedAddNotification(`Titre ${selectedLang.toUpperCase()} mis à jour avec succès`, 'success');
        setIsEditTitleModalOpen(false);
        setSelectedLang(null);
        setEditTitle('');
        await fetchCompanies();
      } catch (error: any) {
        debouncedAddNotification(`Échec de la mise à jour du titre ${selectedLang.toUpperCase()}: ${error.response?.data?.error || error.message}`, 'error');
        console.error('Title update error:', {
          id_entite: editingCompany.id_entite,
          field: `titre_${selectedLang}`,
          message: error.message,
          response: error.response?.data,
        });
      }
    };

const handleSaveCompany = async () => {
  if (!editingCompany) {
    debouncedAddNotification('Aucune entité sélectionnée', 'error');
    return;
  }

  if (!editingCompany.raison_socialle?.trim()) {
    debouncedAddNotification('Raison sociale est requise', 'error');
    return;
  }

  if (
    !editingCompany.email ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editingCompany.email)
  ) {
    debouncedAddNotification('Un email valide est requis', 'error');
    return;
  }

  try {
    // --- Build FormData ---
    const formData = new FormData();
    const appendSafe = (key: string, value: any) =>
      formData.append(key, value ?? '');

    // --- All entity fields ---
    appendSafe('id_entite', editingCompany.id_entite?.toString() || '');
    appendSafe('raison_socialle', editingCompany.raison_socialle.trim());
    appendSafe('gln', editingCompany.gln);
    appendSafe('date_create', editingCompany.date_create);
    appendSafe('pays', editingCompany.pays);
    appendSafe('site', editingCompany.site);
    appendSafe('personne_contact', editingCompany.personne_contact);
    appendSafe('service', editingCompany.service);
    appendSafe('email', editingCompany.email);
    appendSafe('tel_mobile', editingCompany.tel_mobile);
    appendSafe('telephone', editingCompany.telephone);
    appendSafe('fax', editingCompany.fax);
    appendSafe('adresse', editingCompany.adresse);
    appendSafe('region', editingCompany.region);
    appendSafe('city', editingCompany.city);
    appendSafe('localite', editingCompany.localite);
    appendSafe('postalCode', editingCompany.postalCode);
    appendSafe('type_prod', editingCompany.type_prod?.toString());
    appendSafe('statut', editingCompany.statut?.toString());
    appendSafe('date_abonnement', editingCompany.date_abonnement);
    appendSafe('date_echeance', editingCompany.date_echeance);
    appendSafe('inscription', editingCompany.inscription?.toString());
    appendSafe('status_ent', editingCompany.status_ent || 'A');
    appendSafe('delegation', editingCompany.delegation);
    appendSafe('segments', JSON.stringify(modalSegments));
    appendSafe('titre_fr', editingCompany.titre_fr);
    appendSafe('titre_ar', editingCompany.titre_ar);
    appendSafe('titre_en', editingCompany.titre_en);

    // --- Append logo only if selected ---
    if (logoFile) {
      formData.append('logo', logoFile);
    }

    let response;

    if (isCreateMode()) {
      // --- CREATE ---
      response = await axios.post(`${API_BASE_URL}/api/companies`, formData, {
        withCredentials: true,
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const newCompany = response.data;
      setCompanies(prev => [newCompany, ...prev]); // update list immediately
      setEditingCompany(newCompany); // ensure form uses new data
      debouncedAddNotification('Entité créée avec succès', 'success');
    } else {
      // --- UPDATE ---
      const id = editingCompany.id_entite;
      response = await axios.put(
        `${API_BASE_URL}/api/companies/${id}`,
        formData,
        {
          withCredentials: true,
          headers: { 'Content-Type': 'multipart/form-data' },
        }
      );

      // Optionally update local state to show new logo immediately
      const updatedCompany = { ...editingCompany, ...response.data };
      setCompanies(prev =>
        prev.map(c => (c.id_entite === id ? updatedCompany : c))
      );

      debouncedAddNotification('Entité mise à jour avec succès', 'success');
    }

    // --- Clear modal & preview state ---
    setIsModalOpen(false);
    setLogoFile(null);
    setPreviewLogo(null);
    setModalSegments([]);
    setEditingCompany(null);

  } catch (error: any) {
    console.error('Error saving company:', {
      message: error.message,
      response: error.response?.data,
    });

    debouncedAddNotification(
      `Erreur lors de ${
        isCreateMode() ? 'la création' : 'la mise à jour'
      } de l'entité: ${
        error.response?.data?.details || error.message || 'Erreur inconnue'
      }`,
      'error'
    );
  }
};


    const handleDeleteCompany = async (id: number) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      const confirmDelete = window.confirm('Confirmer la suppression ?');
      if (confirmDelete) {
        try {
          await axios.delete(`${API_BASE_URL}/api/companies/${id}`, { withCredentials: true });
          setCompanies(companies.filter(c => c.id_entite !== id));
          setIsActionOpen(null);
          debouncedAddNotification('Entreprise supprimée avec succès', 'success');
        } catch (error: any) {
          debouncedAddNotification(`Échec de la suppression: ${error.response?.data?.error || error.message}`, 'error');
          console.error('Delete error:', {
            id_entite: id,
            message: error.message,
            response: error.response?.data,
          });
        }
      }
    };

    const handleSendConnection = async (email: string) => {
      if (!canWrite) {
        debouncedAddNotification('Vous n\'avez pas la permission de modifier', 'error');
        return;
      }
      try {
        await axios.post(`${API_BASE_URL}/api/send-connection`, { email }, { withCredentials: true });
        setIsActionOpen(null);
        debouncedAddNotification('Détails de connexion envoyés avec succès', 'success');
      } catch (error: any) {
        debouncedAddNotification(`Échec de l'envoi des détails: ${error.response?.data?.error || error.message}`, 'error');
        console.error('Send connection error:', {
          email,
          message: error.message,
          response: error.response?.data,
        });
      }
    };

    const handleSort = (key: keyof Company) => {
      let direction: 'ascending' | 'descending' = 'ascending';
      if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
        direction = 'descending';
      }
      setSortConfig({ key, direction });
      setCurrentPage(1);
      const sortedCompanies = [...companies].sort((a, b) => {
        let aValue: any = a[key];
        let bValue: any = b[key];
        if (['raison_socialle', 'personne_contact', 'email', 'tel_mobile', 'telephone', 'fax', 'adresse', 'region', 'city', 'localite', 'postalCode', 'gln', 'site', 'date_create', 'service', 'status_ent', 'delegation', 'titre_fr', 'titre_ar', 'titre_en', 'logo'].includes(key)) {
          aValue = aValue || '';
          bValue = bValue || '';
        }
        if (aValue === bValue) return 0;
        if (aValue == null) return 1;
        if (bValue == null) return -1;
        if (typeof aValue === 'string') {
          return direction === 'ascending' ? aValue.localeCompare(bValue, undefined, { sensitivity: 'base' }) : bValue.localeCompare(aValue, undefined, { sensitivity: 'base' });
        }
        if (key === 'nb_fp') {
          aValue = ['I', 'Inactive', 'inactive'].includes(a.status_ent?.toString().toUpperCase()) ? 0 : aValue;
          bValue = ['I', 'Inactive', 'inactive'].includes(b.status_ent?.toString().toUpperCase()) ? 0 : bValue;
        }
        return direction === 'ascending' ? aValue - bValue : bValue - aValue;
      });
      setCompanies(sortedCompanies);
    };

    const toggleActionDropdown = (id: number, event: React.MouseEvent) => {
      event.stopPropagation();
      const button = event.currentTarget as HTMLElement;
      const rect = button.getBoundingClientRect();
      const dropdownWidth = 150;
      const dropdownHeight = 200;
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      let left = rect.right - dropdownWidth;
      let top = rect.bottom;
      if (left < 0) left = rect.left;
      if (left + dropdownWidth > viewportWidth) left = viewportWidth - dropdownWidth - 10;
      if (top + dropdownHeight > viewportHeight) top = Math.max(0, rect.top - dropdownHeight);
      setDropdownPosition({ top, left });
      setIsActionOpen(isActionOpen === id ? null : id);
    };

    const renderFormattedText = (text: string | null, companyId: number, lang: string, title: string) => {
      const div = document.createElement('div');
      div.innerHTML = text || '';
      const lineCount = div.innerText.split('\n').length;
      return (
        <div
          className={`max-h-16 overflow-y-auto text-sm transition duration-200 shadow-sm ${lineCount > 5 ? 'text-ellipsis' : ''}`}
          onClick={() => canWrite && openTextModal(text || '', `${lang.toUpperCase()} Description`)}
        >
          <div dangerouslySetInnerHTML={{ __html: text || 'N/A' }} className="mb-1" />
          {lineCount > 5 && (
            <span className="text-blue-950 text-xs">... </span>
          )}
        </div>
      );
    };

    const shouldShowDescriptions = (company: Company) => company.type_prod === 2 || company.type_prod === 6;

    const shouldShowEditDescription = (company: Company) => shouldShowDescriptions(company);

    const totalColumns = 10 + (canWrite ? 1 : 0);

    const isCreateMode = () => {
      if (!editingCompany) return false;
      return !companies.some(c => c.id_entite === editingCompany.id_entite);
    };

    const shouldShowTitleEditors = () => {
      if (isCreateMode()) return false;
      if (!editingCompany) return false;
      return editingCompany.type_prod === 2 || editingCompany.type_prod === 6;
    };

    return (
      <NotificationProvider compteId={compteId}>
        <div className="min-h-screen">
          <nav className="flex items-center space-x-2 text-sm">
            <span
              style={{
                color: '#3b82f6',
                position: 'relative',
                top: '-14px',
                fontWeight: '500',
              }}
            >
              Entité
            </span>
          </nav>

          <style>{`
            .logo-img {
              width: 40px;
              height: 40px;
              object-fit: contain;
              border-radius: 4px;
              cursor: pointer;
            }
            .ql-container {
              font-size: 0.875rem;
            }
            .ql-editor {
              min-height: 150px;
            }
            .action-dropdown {
              position: fixed !important;
              z-index: 9999 !important;
            }
          `}</style>

          <div className="container mx-auto p-6 w-[95vw]">
            <table className="w-full table-fixed">
              <tbody>
                <tr>
                  <td className="w-[15%] px-2">
                    <div className="relative" ref={typeRef}>
                      <label className="block text-sm text-gray-700 mb-1">Type d'opérateur</label>
                      <div
                        className="p-2 border-2 border-gray-400 rounded-md cursor-pointer bg-white text-sm hover:bg-gray-50 w-full flex justify-between items-center h-10"
                        onClick={() => {
                          setIsTypeOpen(!isTypeOpen);
                          setIsRegionOpen(false);
                          setIsSegmentOpen(false);
                          setIsDelegationOpen(false);
                        }}
                      >
                        <span className="truncate">{searchType ? typeOptions.find(t => t.value === searchType)?.label || 'Choisir un type opérateur' : 'Choisir un type opérateur'}</span>
                        <span className="text-blue-950">{isTypeOpen ? '▲' : '▼'}</span>
                      </div>
                      {isTypeOpen && (
                        <div className="absolute z-50 mt-2 w-full bg-white border-2 border-gray-400 rounded-md shadow-lg max-h-[40vh] overflow-auto">
                          <div className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleTypeSelect('')}>
                            Tous les types
                          </div>
                          {typeOptions.map(t => (
                            <div key={t.value} className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleTypeSelect(t.value)}>
                              {t.label}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="w-[15%] px-2">
                    <div className="relative" ref={regionRef}>
                      <label className="block text-sm text-gray-700 mb-1">Région</label>
                      <div
                        className="p-2 border-2 border-gray-400 rounded-md cursor-pointer bg-white text-sm hover:bg-gray-50 w-full flex justify-between items-center h-10"
                        onClick={() => {
                          setIsRegionOpen(!isRegionOpen);
                          setIsSegmentOpen(false);
                          setIsDelegationOpen(false);
                          setIsTypeOpen(false);
                        }}
                      >
                        <span className="truncate">{searchRegion || 'Choisir une région'}</span>
                        <span className="text-blue-950">{isRegionOpen ? '▲' : '▼'}</span>
                      </div>
                      {isRegionOpen && (
                        <div className="absolute z-50 mt-2 w-full bg-white border-2 border-gray-400 rounded-md shadow-lg max-h-[40vh] overflow-auto">
                          <div className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleRegionSelect('')}>
                            Toutes les régions
                          </div>
                          {regions.map(r => (
                            <div key={r.region} className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleRegionSelect(r.region)}>
                              {r.region}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="w-[7%] px-2">
                    <div>
                      <label className="block text-sm text-gray-700 mb-1">‎ </label>
                      <input
                        type="text"
                        value={searchText}
                        onChange={e => {
                          setSearchText(e.target.value);
                          setCurrentPage(1);
                        }}
                        placeholder="🔍︎ Rechercher"
                        className="w-full p-2 border-2 border-gray-400 rounded-md text-sm h-10"
                      />
                    </div>
                  </td>
                  <td className="w-[7%] px-2">
                    <div>
                      <label className="block text-sm text-gray-700 mb-1">Total Entités</label>
                      <div className="w-24 h-10 flex justify-center items-center bg-gray-200 rounded-md text-blue-950 font-mono text-lg">
                        {visibleTotal.toString().padStart(4, '0')}
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="w-[15%] px-2">
                    <div className="relative" ref={segmentRef}>
                      <label className="block text-sm text-gray-700 mb-1">Secteur</label>
                      <div
                        className="p-2 border-2 border-gray-400 rounded-md cursor-pointer bg-white text-sm hover:bg-gray-50 w-full flex justify-between items-center h-10"
                        onClick={() => {
                          setIsSegmentOpen(!isSegmentOpen);
                          setIsRegionOpen(false);
                          setIsDelegationOpen(false);
                          setIsTypeOpen(false);
                        }}
                      >
                        <span className="truncate">{searchSegment ? segments.find(s => s.code === searchSegment)?.libelle || 'Choisir un secteur' : 'Choisir un secteur'}</span>
                        <span className="text-blue-950">{isSegmentOpen ? '▲' : '▼'}</span>
                      </div>
                      {isSegmentOpen && (
                        <div className="absolute z-50 mt-2 w-full bg-white border-2 border-gray-400 rounded-md shadow-lg max-h-[40vh] overflow-auto">
                          <div className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleSegmentSelect('')}>
                            Tous les segments
                          </div>
                          {segments.map(s => (
                            <div key={s.code} className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleSegmentSelect(s.code)}>
                              {s.libelle}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="w-[15%] px-2">
                    <div className="relative" ref={delegationRef}>
                      <label className="block text-sm text-gray-700 mb-1">Délégation ou Ville</label>
                      <div
                        className="p-2 border-2 border-gray-400 rounded-md cursor-pointer bg-white text-sm hover:bg-gray-50 w-full flex justify-between items-center h-10"
                        onClick={() => {
                          setIsDelegationOpen(!isDelegationOpen);
                          setIsRegionOpen(false);
                          setIsSegmentOpen(false);
                          setIsTypeOpen(false);
                        }}
                      >
                        <span className="truncate">{searchDelegation || 'Choisir une délégation/ville'}</span>
                        <span className="text-blue-950">{isDelegationOpen ? '▲' : '▼'}</span>
                      </div>
                      {isDelegationOpen && (
                        <div className="absolute z-50 mt-2 w-full bg-white border-2 border-gray-400 rounded-md shadow-lg max-h-[40vh] overflow-auto">
                          <div className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleDelegationSelect('')}>
                            Toutes les délégations
                          </div>
                          {delegations.map(d => (
                            <div key={d.delegation} className="p-2 hover:bg-gray-100 cursor-pointer text-sm" onClick={() => handleDelegationSelect(d.delegation)}>
                              {d.delegation}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="w-[20%] px-2">
                    <div className="flex justify-between items-center h-10 space-x-2">
                      <div className="flex items-center space-x-2 flex-1">
                        <select
                          value={itemsPerPage}
                          onChange={e => {
                            setItemsPerPage(Number(e.target.value));
                            setCurrentPage(1);
                          }}
                          className="p-1 border rounded text-sm"
                        >
                          <option value={10}>10</option>
                          <option value={25}>25</option>
                          <option value={50}>50</option>
                          <option value={100}>100</option>
                        </select>
                      </div>
                      {canWrite && (
                        <div className="relative" ref={mainActionRef} style={{ flexShrink: 0 }}>
                          <button
                            className="px-4 py-2 bg-blue-950 text-white rounded-md hover:bg-blue-900 text-sm h-10"
                            onClick={() => {
                              setIsMainActionOpen(!isMainActionOpen);
                              setIsRegionOpen(false);
                              setIsSegmentOpen(false);
                              setIsDelegationOpen(false);
                              setIsTypeOpen(false);
                            }}
                          >
                            Actions
                          </button>
                          {isMainActionOpen && (
                            <div className="absolute z-50 mt-2 right-0 bg-white border-2 border-gray-400 rounded-md shadow-lg">
                              <div
                                className="p-2 hover:bg-gray-100 cursor-pointer text-sm"
                                onClick={handleAddCompany}
                              >
                                Ajouter une entité
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="w-[7%] px-2"></td>
                </tr>
              </tbody>
            </table>

            <div className="mt-4 overflow-visible" ref={tableRef}>
              <table className="w-full text-sm table-fixed">
                <thead className="bg-blue-950 text-white sticky top-0 z-10">
                  <tr>
                    <th className="w-[5%] p-2"></th>
                    <th className="w-[5%] p-2 cursor-pointer" onClick={() => handleSort('id_entite')}>
                      ID {sortConfig?.key === 'id_entite' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[5%] p-2">Logo</th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('raison_socialle')}>
                      Raison sociale {sortConfig?.key === 'raison_socialle' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('personne_contact')}>
                      Contact {sortConfig?.key === 'personne_contact' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('email')}>
                      Email {sortConfig?.key === 'email' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('tel_mobile')}>
                      Mobile {sortConfig?.key === 'tel_mobile' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('adresse')}>
                      Adresse {sortConfig?.key === 'adresse' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('region')}>
                      Région {sortConfig?.key === 'region' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[10%] p-2 cursor-pointer" onClick={() => handleSort('city')}>
                      Ville {sortConfig?.key === 'city' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </th>
                    <th className="w-[15%] p-2">Segments</th>
                    {canWrite && (
                      <th className="w-[5%] p-2">Actions</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {paginatedCompanies.map(company => (
                    <React.Fragment key={company.id_entite}>
                      <tr className="border-b hover:bg-gray-50">
                        <td className="p-2 text-center">
                          <button
                            className="text-blue-950 hover:text-blue-700"
                            onClick={() => toggleRow(company.id_entite)}
                          >
                            {expandedRow === company.id_entite ? '−' : '+'}
                          </button>
                        </td>
                        <td className="p-2 text-center">{company.id_entite}</td>
                        <td className="p-2 text-center">
                          {company.logo ? (
                            <img
                              src={getLogoUrl(company.logo)}
                              alt="Logo"
                              className="logo-img"
                              onClick={() => openLogoModal(getLogoUrl(company.logo))}
                              onError={(e) => handleLogoError(e, company.id_entite)}
                            />
                          ) : (
                            'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'raison_socialle',
                                value: company.raison_socialle,
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'raison_socialle' ? (
                            <input
                              type="text"
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'raison_socialle', editingField.value)}
                              onKeyPress={e => e.key === 'Enter' && handleEditField(company.id_entite, 'raison_socialle', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            />
                          ) : (
                            company.raison_socialle
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'personne_contact',
                                value: company.personne_contact || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'personne_contact' ? (
                            <input
                              type="text"
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'personne_contact', editingField.value)}
                              onKeyPress={e => e.key === 'Enter' && handleEditField(company.id_entite, 'personne_contact', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            />
                          ) : (
                            company.personne_contact || 'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'email',
                                value: company.email || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'email' ? (
                            <input
                              type="email"
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'email', editingField.value)}
                              onKeyPress={e => e.key === 'Enter' && handleEditField(company.id_entite, 'email', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            />
                          ) : (
                            company.email || 'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'tel_mobile',
                                value: company.tel_mobile || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'tel_mobile' ? (
                            <input
                              type="text"
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'tel_mobile', editingField.value)}
                              onKeyPress={e => e.key === 'Enter' && handleEditField(company.id_entite, 'tel_mobile', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            />
                          ) : (
                            company.tel_mobile || 'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'adresse',
                                value: company.adresse || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'adresse' ? (
                            <input
                              type="text"
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'adresse', editingField.value)}
                              onKeyPress={e => e.key === 'Enter' && handleEditField(company.id_entite, 'adresse', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            />
                          ) : (
                            company.adresse || 'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'region',
                                value: company.region || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'region' ? (
                            <select
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'region', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            >
                              <option value="">Sélectionner</option>
                              {regions.map(r => (
                                <option key={r.region} value={r.region}>{r.region}</option>
                              ))}
                            </select>
                          ) : (
                            company.region || 'N/A'
                          )}
                        </td>
                        <td
                          className="p-2 truncate"
                          onClick={e => {
                            e.stopPropagation();
                            if (canWrite) {
                              setEditingField({
                                id: company.id_entite,
                                field: 'city',
                                value: company.city || '',
                              });
                            }
                          }}
                        >
                          {editingField?.id === company.id_entite && editingField?.field === 'city' ? (
                            <select
                              value={editingField.value}
                              onChange={e => setEditingField({ ...editingField, value: e.target.value })}
                              onBlur={() => handleEditField(company.id_entite, 'city', editingField.value)}
                              className="w-full p-1 border rounded"
                              autoFocus
                            >
                              <option value="">Sélectionner</option>
                              {delegations.map(d => (
                                <option key={d.delegation} value={d.delegation}>{d.delegation}</option>
                              ))}
                            </select>
                          ) : (
                            company.city || 'N/A'
                          )}
                        </td>
                        <td className="p-2">
                          {company.segments?.slice(0, 4).map(s => segments.find(seg => seg.code === s)?.libelle).filter(Boolean).join(', ') || 'N/A'}
                        </td>
                        {canWrite && (
                          <td className="p-2 text-center relative">
                            <button
                              className="text-blue-950 hover:text-blue-700"
                              onClick={e => toggleActionDropdown(company.id_entite, e)}
                            >
                              ☰
                            </button>
                            {isActionOpen === company.id_entite && dropdownPosition && (
                              <div
                                className="action-dropdown bg-white border-2 border-gray-400 rounded-md shadow-lg text-sm"
                                style={{ top: dropdownPosition.top, left: dropdownPosition.left, width: '150px' }}
                              >
                                <div
                                  className="p-2 hover:bg-gray-100 cursor-pointer"
                                  onClick={() => handleEditCompany(company)}
                                >
                                  Modifier
                                </div>
                                {shouldShowEditDescription(company) && (
                                  <div
                                    className="p-2 hover:bg-gray-100 cursor-pointer"
                                    onClick={() => openSelectLangModal(company)}
                                  >
                                    Modifier description
                                  </div>
                                )}
                                {!profileExists[company.id_entite] && (
                                  <div
                                    className="p-2 hover:bg-gray-100 cursor-pointer"
                                    onClick={() => handleCreateSupervisorProfile(company)}
                                  >
                                    Créer profil superviseur
                                  </div>
                                )}
                                {company.email && (
                                  <div
                                    className="p-2 hover:bg-gray-100 cursor-pointer"
                                    onClick={() => handleSendConnection(company.email!)}
                                  >
                                    Envoyer détails connexion
                                  </div>
                                )}
                                <div
                                  className="p-2 hover:bg-gray-100 cursor-pointer text-red-600"
                                  onClick={() => handleDeleteCompany(company.id_entite)}
                                >
                                  Supprimer
                                </div>
                              </div>
                            )}
                          </td>
                        )}
                      </tr>
                      {expandedRow === company.id_entite && (
                        <tr className="bg-gray-100">
                          <td colSpan={totalColumns} className="p-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p><strong>GLN:</strong> {company.gln || 'N/A'}</p>
                                <p><strong>Site:</strong> {company.site || 'N/A'}</p>
                                <p><strong>Date de création:</strong> {company.date_create || 'N/A'}</p>
                                <p><strong>Service:</strong> {company.service || 'N/A'}</p>
                                <p><strong>Téléphone:</strong> {company.telephone || 'N/A'}</p>
                                <p><strong>Fax:</strong> {company.fax || 'N/A'}</p>
                                <p><strong>Localité:</strong> {company.localite || 'N/A'}</p>
                                <p><strong>Code postal:</strong> {company.postalCode || 'N/A'}</p>
                              </div>
                              <div>
                                <p><strong>Type:</strong> {typeOptions.find(t => t.value === company.type_prod.toString())?.label || 'N/A'}</p>
                                <p><strong>Statut:</strong> {company.statut === 1 ? 'Actif' : 'Inactif'}</p>
                                <p><strong>Date d'abonnement:</strong> {company.date_abonnement || 'N/A'}</p>
                                <p><strong>Date d'échéance:</strong> {company.date_echeance || 'N/A'}</p>
                                <p><strong>Nombre de FP:</strong> {company.nb_fp || 0}</p>
                                <p><strong>Inscription:</strong> {company.inscription === 1 ? 'Oui' : 'Non'}</p>
                                <p><strong>Statut entité:</strong> {company.status_ent === 'A' ? 'Actif' : 'Inactif'}</p>
                                <p><strong>Délégation:</strong> {company.delegation || 'N/A'}</p>
                              </div>
                              {shouldShowDescriptions(company) && (
                                <div className="col-span-2">
                                  <p><strong>Description FR:</strong> {renderFormattedText(company.titre_fr, company.id_entite, 'fr', 'Description FR')}</p>
                                  <p><strong>Description AR:</strong> {renderFormattedText(company.titre_ar, company.id_entite, 'ar', 'Description AR')}</p>
                                  <p><strong>Description EN:</strong> {renderFormattedText(company.titre_en, company.id_entite, 'en', 'Description EN')}</p>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-4 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <span className="text-sm">Afficher</span>
                <select
                  value={itemsPerPage}
                  onChange={e => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="p-1 border rounded text-sm"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
                <span className="text-sm">par page</span>
              </div>
              <div className="flex space-x-2">
                <button
                  className="px-3 py-1 bg-blue-950 text-white rounded disabled:opacity-50"
                  onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </button>
                <span className="text-sm">Page {currentPage} sur {Math.ceil(filteredCompanies.length / itemsPerPage)}</span>
                <button
                  className="px-3 py-1 bg-blue-950 text-white rounded disabled:opacity-50"
                  onClick={() => setCurrentPage(p => p + 1)}
                  disabled={currentPage >= Math.ceil(filteredCompanies.length / itemsPerPage)}
                >
                  Suivant
                </button>
              </div>
            </div>

            {isModalOpen && editingCompany && (
              <Draggable handle=".modal-handle">
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                  <div className="bg-white rounded-lg shadow-lg w-[90vw] max-w-6xl max-h-[90vh] overflow-auto" ref={modalRef}>
                    <div className="modal-handle bg-blue-950 text-white p-2 flex justify-between items-center cursor-move">
                      <h2 className="text-lg">{isCreateMode() ? 'Ajouter une entité' : 'Modifier l’entité'}</h2>
                      <button onClick={() => { setIsModalOpen(false); setRawLogo(null); setPreviewLogo(null); }} className="text-white hover:text-gray-300">
                        <XMarkIcon className="h-6 w-6" />
                      </button>
                    </div>
                    <div className="p-4 grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Logo</label>
                        {previewLogo ? (
                          <div className="logo-preview-container">
                            <img
                              src={previewLogo}
                              alt="Logo Preview"
                              className="logo-preview"
                              onClick={() => openLogoModal(previewLogo)}
                              onError={(e) => handleLogoError(e, editingCompany.id_entite)}
                            />
                            <button
                              className="logo-preview-delete"
                              onClick={handleLogoDelete}
                            >
                              ×
                            </button>
                          </div>
                        ) : (
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleLogoFileChange}
                            className="w-full p-2 border rounded text-sm"
                          />
                        )}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Raison sociale *</label>
                        <input
                          type="text"
                          value={editingCompany.raison_socialle}
                          onChange={e => setEditingCompany({ ...editingCompany, raison_socialle: e.target.value })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">GLN</label>
                        <input
                          type="text"
                          value={editingCompany.gln || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, gln: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date de création</label>
                        <input
                          type="date"
                          value={editingCompany.date_create || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, date_create: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Pays</label>
                        <input
                          type="text"
                          value={editingCompany.pays || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, pays: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Site</label>
                        <input
                          type="text"
                          value={editingCompany.site || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, site: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Personne de contact</label>
                        <input
                          type="text"
                          value={editingCompany.personne_contact || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, personne_contact: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                        <input
                          type="text"
                          value={editingCompany.service || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, service: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                        <input
                          type="email"
                          value={editingCompany.email || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, email: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone mobile</label>
                        <input
                          type="tel"
                          value={editingCompany.tel_mobile || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, tel_mobile: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                        <input
                          type="tel"
                          value={editingCompany.telephone || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, telephone: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Fax</label>
                        <input
                          type="tel"
                          value={editingCompany.fax || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, fax: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Adresse</label>
                        <input
                          type="text"
                          value={editingCompany.adresse || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, adresse: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Région</label>
                        <select
                          value={editingCompany.region || ''}
                          onChange={handleModalRegionChange}
                          className="w-full p-2 border rounded text-sm"
                        >
                          <option value="">Sélectionner une région</option>
                          {regions.map(r => (
                            <option key={r.region} value={r.region}>{r.region}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Ville / Délégation</label>
                        <select
                          value={editingCompany.city || ''}
                          onChange={handleModalCityChange}
                          className="w-full p-2 border rounded text-sm"
                        >
                          <option value="">Sélectionner une ville</option>
                          {delegations.map(d => (
                            <option key={d.delegation} value={d.delegation}>{d.delegation}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Localité</label>
                        <input
                          type="text"
                          value={editingCompany.localite || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, localite: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Code postal</label>
                        <input
                          type="text"
                          value={editingCompany.postalCode || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, postalCode: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Type d'opérateur</label>
                        <select
                          value={editingCompany.type_prod.toString()}
                          onChange={e => setEditingCompany({ ...editingCompany, type_prod: Number(e.target.value) })}
                          className="w-full p-2 border rounded text-sm"
                        >
                          {typeOptions.map(t => (
                            <option key={t.value} value={t.value}>{t.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                        <select
                          value={editingCompany.statut.toString()}
                          onChange={e => setEditingCompany({ ...editingCompany, statut: Number(e.target.value) })}
                          className="w-full p-2 border rounded text-sm"
                        >
                          {statutOptions.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date d'abonnement</label>
                        <input
                          type="date"
                          value={editingCompany.date_abonnement || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, date_abonnement: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date d'échéance</label>
                        <input
                          type="date"
                          value={editingCompany.date_echeance || ''}
                          onChange={e => setEditingCompany({ ...editingCompany, date_echeance: e.target.value || null })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Nombre de FP</label>
                        <input
                          type="number"
                          value={editingCompany.nb_fp}
                          onChange={e => setEditingCompany({ ...editingCompany, nb_fp: Number(e.target.value) })}
                          className="w-full p-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Inscription</label>
                        <select
                          value={editingCompany.inscription.toString()}
                          onChange={e => setEditingCompany({ ...editingCompany, inscription: Number(e.target.value) })}
                          className="w-full p-2 border rounded text-sm"
                        >
                          {inscriptionOptions.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Statut entité</label>
                        <select
                          value={editingCompany.status_ent}
                          onChange={e => setEditingCompany({ ...editingCompany, status_ent: e.target.value })}
                          className="w-full p-2 border rounded text-sm"
                        >
                          <option value="A">Actif</option>
                          <option value="I">Inactif</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Segments (max 4)</label>
                        <div className="flex flex-wrap gap-2">
                          {segments.map(s => (
                            <label key={s.code} className="flex items-center space-x-2 text-sm">
                              <input
                                type="checkbox"
                                checked={modalSegments.includes(s.code)}
                                onChange={() => {
                                  setModalSegments(prev => {
                                    if (prev.includes(s.code)) {
                                      return prev.filter(code => code !== s.code);
                                    }
                                    if (prev.length < 4) {
                                      return [...prev, s.code];
                                    }
                                    debouncedAddNotification('Maximum 4 segments autorisés', 'error');
                                    return prev;
                                  });
                                }}
                                className="rounded"
                              />
                              <span>{s.libelle}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="p-4 flex justify-end space-x-2">
                      <button
                        onClick={() => { setIsModalOpen(false); setLogoFile(null); setPreviewLogo(null); }}
                        className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                      >
                        Annuler
                      </button>
                      <button
                        onClick={handleSaveCompany}
                        className="px-4 py-2 bg-blue-950 text-white rounded hover:bg-blue-900"
                      >
                        Sauvegarder
                      </button>
                    </div>
                  </div>
                </div>
              </Draggable>
            )}

            {isSelectLangModalOpen && editingCompany && (
              <Draggable handle=".modal-handle">
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                  <div className="bg-white rounded-lg shadow-lg w-80" ref={selectLangModalRef}>
                    <div className="modal-handle bg-blue-950 text-white p-2 flex justify-between items-center cursor-move">
                      <h2 className="text-lg">Sélectionner la langue</h2>
                      <button onClick={() => setIsSelectLangModalOpen(false)} className="text-white hover:text-gray-300">
                        <XMarkIcon className="h-6 w-6" />
                      </button>
                    </div>
                    <div className="p-4">
                      <button
                        className="w-full p-2 mb-2 bg-gray-100 hover:bg-gray-200 rounded text-sm"
                        onClick={() => openEditTitleModal('fr')}
                      >
                        Français
                      </button>
                      <button
                        className="w-full p-2 mb-2 bg-gray-100 hover:bg-gray-200 rounded text-sm"
                        onClick={() => openEditTitleModal('ar')}
                      >
                        Arabe
                      </button>
                      <button
                        className="w-full p-2 bg-gray-100 hover:bg-gray-200 rounded text-sm"
                        onClick={() => openEditTitleModal('en')}
                      >
                        Anglais
                      </button>
                    </div>
                  </div>
                </div>
              </Draggable>
            )}

            {isEditTitleModalOpen && selectedLang && (
              <Draggable handle=".modal-handle">
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                  <div className="bg-white rounded-lg shadow-lg w-[90vw] max-w-4xl" ref={editTitleModalRef}>
                    <div className="modal-handle bg-blue-950 text-white p-2 flex justify-between items-center cursor-move">
                      <h2 className="text-lg">Modifier le titre {selectedLang.toUpperCase()}</h2>
                      <button onClick={() => setIsEditTitleModalOpen(false)} className="text-white hover:text-gray-300">
                        <XMarkIcon className="h-6 w-6" />
                      </button>
                    </div>
                    <div className="p-4">
                      <ReactQuill
                        value={editTitle}
                        onChange={setEditTitle}
                        modules={quillModules}
                        className="mb-4"
                      />
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => setIsEditTitleModalOpen(false)}
                          className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={handleTitleUpdate}
                          className="px-4 py-2 bg-blue-950 text-white rounded hover:bg-blue-900"
                        >
                          Sauvegarder
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </Draggable>
            )}

            {isTextModalOpen && (
              <Draggable handle=".modal-handle">
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                  <div className="bg-white rounded-lg shadow-lg w-[90vw] max-w-4xl" ref={textModalRef}>
                    <div className="modal-handle bg-blue-950 text-white p-2 flex justify-between items-center cursor-move">
                      <h2 className="text-lg">{selectedTextTitle}</h2>
                      <button onClick={() => setIsTextModalOpen(false)} className="text-white hover:text-gray-300">
                        <XMarkIcon className="h-6 w-6" />
                      </button>
                    </div>
                    <div className="p-4">
                      <div
                        className="ql-editor"
                        dangerouslySetInnerHTML={{ __html: selectedText || 'N/A' }}
                      />
                      <div className="flex justify-end mt-4">
                        <button
                          onClick={() => setIsTextModalOpen(false)}
                          className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                        >
                          Fermer
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </Draggable>
            )}

            {isLogoModalOpen && selectedLogo && (
              <Draggable handle=".modal-handle">
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                  <div className="bg-white rounded-lg shadow-lg w-[90vw] max-w-md" ref={logoModalRef}>
                    <div className="modal-handle bg-blue-950 text-white p-2 flex justify-between items-center cursor-move">
                      <h2 className="text-lg">Aperçu du logo</h2>
                      <button onClick={() => setIsLogoModalOpen(false)} className="text-white hover:text-gray-300">
                        <XMarkIcon className="h-6 w-6" />
                      </button>
                    </div>
                    <div className="p-4 flex justify-center">
                      <img
                        src={selectedLogo}
                        alt="Logo"
                        className="max-w-full max-h-[50vh] object-contain"
                      />
                    </div>
                  </div>
                </div>
              </Draggable>
            )}
          </div>
        </div>
      </NotificationProvider>
    );
  };

  export default Entite;