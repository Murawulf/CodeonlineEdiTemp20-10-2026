import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useTranslation } from "@/contexts/TranslationContext";
import logo from "../components/layout/logo.png"; // Adjust path if needed

const API_BASE_URL = "https://codeonline-edi.net/";

interface Permission {
  page_id: number;
  read: number;
  write: number;
  hide: number;
  page_name?: string;
}

interface Compte {
  id_compte: number;
  email: string;
  name: string;
  profile_id: number;
  permissions: Permission[];
  certicode?: string | null;
  role?: string | null;
  is_suspended: number;
  created_at: string;
  id_entite: number;
  producer_name: string | null;
}

const Login: React.FC = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [certicode, setCerticode] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isCerticodeModalOpen, setIsCerticodeModalOpen] = useState<boolean>(false);
  const [timer, setTimer] = useState<number>(60);
  const navigate = useNavigate();

  const isBackoffice = email === "fp_back_office@codeonline-info.com";

  // Handle certicode modal timeout
  useEffect(() => {
    let timerId: NodeJS.Timeout | null = null;
    if (isCerticodeModalOpen && !isBackoffice) {
      timerId = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            setIsCerticodeModalOpen(false);
            setCerticode("");
            toast.info(t("certicode_timeout") || "Le temps pour entrer le certicode est écoulé");
            return 60;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isCerticodeModalOpen, isBackoffice, t]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error(t("email_password_required") || "Email et mot de passe requis");
      return;
    }
    setIsLoading(true);
    try {
      const payload: { email: string; password: string; certicode?: string } = { email, password };
      if (isCerticodeModalOpen && certicode) {
        payload.certicode = certicode;
      }

      const response = await axios.post(`${API_BASE_URL}/api/login`, payload, {
        withCredentials: true,
      });
      console.log("Login API response:", response.data);

      if (response.data.status === "certicode_sent") {
        setIsCerticodeModalOpen(true);
        setTimer(60);
        toast.success(t("Certicode envoyé") || "Certicode envoyé à votre email");
        return;
      }

      const userData: Compte = response.data;
      localStorage.setItem("user", JSON.stringify(userData));
      console.log("Stored user in localStorage:", userData);

      toast.success(t("Connexion réussie") || "Connexion réussie");
      setTimeout(() => navigate("/"), 2500);
    } catch (error: any) {
      console.error("Login error:", error);
      const errorMessage = error.response?.data?.error || t("login_failed") || "Échec de la connexion";
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
      if (isCerticodeModalOpen) {
        setCerticode("");
        setTimer(60);
      }
    }
  };

  const handleCerticodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleLogin(e);
  };

 return (
  <div className="flex flex-col min-h-screen bg-white">
    <ToastContainer position="top-right" autoClose={3000} theme="dark" />

    {/* Main Content */}
    <div className="flex flex-grow items-center justify-center">
      <div className="flex w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden">
        {/* Left Side - Logo and Branding */}
        <div className="hidden md:flex flex-col items-center justify-center w-1/2 bg-white text-gray-800 p-8 space-y-6">
          <img
            src="https://codeonline-edi.net//lovable-uploads/a13c1ffe-9c2c-4e6a-a048-063ce7274535.png"
            alt="Netconsulting Europe Logo"
            className="w-48 max-h-24 object-contain"
          />
          <h3 className="text-xl font-">Bienvenue sur Codeonline EDI</h3>
          <p className="text-sm text-center text-gray-600">It's time to standard</p>
        </div>

        {/* Right Side - Login Form */}
        <div className="w-full md:w-1/2 p-8 md:p-12">
          <h2 className="text-3xl font- mb-8 text-center text-gray-800">
            {t("Connexion") || "Connexion"}
          </h2>
          <div onSubmit={handleLogin} className="space-y-6">
            <div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#001861] transition bg-gray-50 hover:bg-white"
                placeholder={t("email") || "Entrez votre courriel"}
                required
              />
            </div>
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#001861] transition bg-gray-50 hover:bg-white"
                placeholder={t("Mot de passe") || "Entrez votre mot de passe"}
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              onClick={handleLogin}
              className={`w-full py-3 px-4 bg-[#001861] text-white rounded-lg hover:bg-[#003087] transition transform hover:scale-105 ${
                isLoading ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              {isLoading
                ? t("loading") || "Connexion en cours..."
                : t("Se connecter") || "Se connecter"}
            </button>
          </div>
        </div>
      </div>
    </div>

    {/* Footer - always at bottom */}
    <footer className="w-full border-t py-6">
      <div className="container mx-auto px-4 text-center">
        <img
          src={logo}
          alt="Netconsulting Europe"
          className="h-32 mx-auto mb-4"
        />
        <div className="text-xs text-muted-foreground -mt-1">
          Copyrights © {new Date().getFullYear()} Netconsulting Europe LTD —
          Tous droits réservés
        </div>
      </div>
    </footer>

    {/* Certicode Modal */}
    {isCerticodeModalOpen && !isBackoffice && (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-xl">
          <h3 className="text-xl font- mb-4 text-gray-800">
            Veuillez saisir votre certicode
          </h3>
          <form onSubmit={handleCerticodeSubmit} className="space-y-4">
            <div>
             
              <input
                type="text"
                value={certicode}
                onChange={(e) => setCerticode(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#001861] transition bg-gray-50"
                placeholder={t("veuillez saisir votre certicode") || "Entrez le certicode"}
                required
                autoFocus
              />
              <p className="text-sm text-gray-500 mt-2">
                {t("temps restant") || "Temps restant"}: {timer} &nbsp;secondes
              </p>
            </div>
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => {
                  setIsCerticodeModalOpen(false);
                  setCerticode("");
                  setTimer(60);
                }}
                className="py-2 px-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className={`py-2 px-4 bg-[#001861] text-white rounded-lg hover:bg-[#003087] transition ${
                  isLoading ? "opacity-50 cursor-not-allowed" : ""
                }`}
              >
                {isLoading
                  ? t("Vérification en cours...") || "Vérification en cours..."
                  : t("Valider") || "Vérifier le certicode"}
              </button>
            </div>
          </form>
        </div>
      </div>
    )}
  </div>
);

};

export default Login;